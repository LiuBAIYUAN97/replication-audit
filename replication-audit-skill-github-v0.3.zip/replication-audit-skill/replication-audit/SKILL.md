---
name: replication-audit
description: Audit and harden a replication package for empirical research (economics, management, social science) so it reproduces the same results on any computer and under any AI agent, and surface signs of AI-related errors. Scans Python, Stata and R code for non-reproducibility; runs the package in controlled and perturbed environments; stores a baseline and re-checks later runs or outputs from another machine; traces pandas sample-size changes; verifies numbers printed in the paper against outputs; flags inconsistent t/p columns, orphan output files, AI markers in figure metadata, and mismatches with an AI-use declaration. Use for replication package, reproducibility, 复现包, 复现审计, AI-written analysis code that may be wrong, data-editor checks, or comparing results across machines or agents.
---

# replication-audit (v0.3)

Purpose: help an author find out whether an analysis pipeline reproduces its own tables and figure data, and surface what prevents it or looks suspicious. All pass/fail decisions are made by the scripts in `scripts/`, not by you. Your job is to run them, relay results faithfully, and help the author fix causes.

Requires Python >= 3.11 to run the tool. Scripts use only the standard library. The audited project brings its own dependencies and, for Stata/R projects, its own Stata/R installation.

## Hard rules

1. Never edit `repro_baseline/`, `repro_report.*`, or tolerances in `repro.toml` to make a check pass. `check` uses the tolerances saved in the baseline anyway.
2. Never change the author's analysis code during `baseline` or `check`. Propose fixes; the author decides. Analysis choices are theirs.
3. Do not paraphrase a failure into a pass. Quote the verdict word (`PASS`, `FAIL`, `UNSTABLE`, `RUN_FAILED`) and the cited file/cell/step as printed.
4. Findings are evidence, not accusations. Never state or imply research misconduct. `provenance` output is heuristic: say what was found and where, mark it "needs human review", and never present absence of a signal as proof of anything.
5. Reply to the user in the language they write in.

## Workflow

Run by absolute path. `ROOT` is the project folder.

1. **Manifest.** If `ROOT/repro.toml` is missing, run `python scripts/audit.py init ROOT`, then review the draft with the author (entry command, inputs, declared outputs, tolerances). Format: `references/manifest.md`. Declare table/figure-data files as outputs; declare image files with `compare = "none"` and compare their underlying data instead.
2. **Scan.** `python scripts/audit.py scan ROOT` covers Python, Stata and R, with file and line. Rules: `references/rules.md`. Fix `error` findings before step 3; discuss `warn` findings with the author.
3. **Baseline.** `python scripts/audit.py baseline ROOT` runs the package in two clean copies, one controlled and one perturbed (different hash seed, thread count, time zone, and a path containing a space). If outputs or the sample flow differ beyond tolerance it exits 2 with `UNSTABLE` and saves nothing. Use scan output to find the cause. Do not use `--force` unless the user explicitly asks. The baseline also lists sample-flow warnings (TR001 merge added rows, TR002/TR003 large drops) and orphan files; ask the author to explain each.
4. **Check.** `python scripts/audit.py check ROOT` re-runs in a clean copy and compares with the baseline: outputs within tolerance, input-file hashes, sample flow, orphan files, and every `[[claims]]` entry (numbers printed in the paper vs output cells; a mismatch is a FAIL). Help the author register key paper numbers as claims (`references/manifest.md`). TB001/TB002 warnings flag regression tables whose t or p columns are internally inconsistent. On another computer or agent, copy the whole project including `repro_baseline/` and run the same command. To compare results produced elsewhere without re-running: `check ROOT --outputs OTHER_ROOT` (sample flow and orphans are then not checked).
5. **Provenance (heuristic).** `python scripts/audit.py provenance ROOT --with-run` inspects figure metadata for AI-generation indicators and content credentials, finds orphan files, and compares the `[disclosure]` declaration with text mentions and git co-author trailers. It never produces FAIL; it produces a list for human review.
6. **Report.** Summarise `repro_report.md` / `repro_report.json` (and `repro_provenance.json`): verdict, differing outputs with largest differences, sample-flow table and warnings, orphans, input changes, environment differences (often the explanation for a failure).

Exit codes: 0 pass, 1 fail, 2 unstable, 3 setup error.

## Scope and honest limits

- Running (`baseline`/`check`) is language-agnostic: any single command in `[project].command`. It has been tested end to end only with Python. Stata/R runs, and `[env_capture]` for recording Stata/R versions, are untested against real Stata/R; Stata/R scanning is text-pattern based and has been tested on fixtures only.
- Sample-flow tracing covers pandas only (merge, join, concat, dropna, drop_duplicates, query, boolean-mask filters) and only for calls made directly from the project's own files, when the command is `python script.py`. Stata/R sample tracking is not implemented.
- Images are not compared pixel by pixel; compare their data files. Metadata can be stripped, and AI-image detection from pixels is out of scope.
- The disclosure check is weak evidence in both directions. Mentions can be benign; AI use leaves no trace in most projects.
- A passing audit shows the package reproduces its own baseline under the tested environments. It does not show the analysis is correct or the research is sound.

## Self-test

`python tests/run_tests.py` (needs numpy, pandas, matplotlib) builds demo packages and verifies 31 behaviours, including catching unseeded randomness, hash-order dependence, silent sample restriction, changed inputs, loosened tolerances, merge fan-out, orphan files, AI metadata markers, declaration mismatches, inconsistent t/p columns and paper numbers that do not match outputs. `references/quickstart_zh.md` has a Chinese walk-through; `tests/make_demo.py DEST` makes demo packages to try by hand. Run it after any change to the scripts.
