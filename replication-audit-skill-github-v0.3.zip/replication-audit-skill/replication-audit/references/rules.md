# Scan rules

Severity: error = blocks a trustworthy baseline; warn = discuss with author; info = awareness.

| ID | Sev | Meaning | Typical fix |
|---|---|---|---|
| R001 | error | numpy global sampler used with no seed anywhere, or `default_rng()`/`RandomState()` without a seed | `rng = np.random.default_rng(SEED)` and use `rng` everywhere |
| R002 | error | stdlib `random` sampler with no `random.seed` anywhere | `random.seed(SEED)` once at start |
| R003 | warn | sklearn-style stochastic estimator or splitter without `random_state` | pass `random_state=SEED` |
| R004 | warn | `.sample()` without `random_state` | pass `random_state=SEED` |
| R005 | warn | absolute / machine-specific path literal | use paths relative to project root |
| R006 | warn | `os.chdir` / `os.getcwd` | avoid; resolve paths from project root |
| R007 | error | `input()` | remove; parameters belong in code or config |
| R008 | warn | `now()/today()/time.time()` | do not let results depend on the clock |
| R009 | warn | `merge` without `validate=` | add `validate="1:1"` / `"m:1"` etc. and check row counts |
| R010 | info | `sort_values` without `kind` | add `kind="stable"` and a unique tie-break key |
| R011 | warn | result-like name (coef, beta, se, pval, ...) assigned a literal with >2 decimals | compute it from data; if a literature value, name it and cite the source |
| R012 | info | pyplot without a backend selection | `matplotlib.use("Agg")` |
| R013 | warn | `plt.show()` | `fig.savefig(...)` |
| R014 | warn | `except Exception: pass` | catch specific errors and fail loudly |
| R015 | error | file does not parse | fix syntax |
| P001 | error | no readable `repro.toml` | write one (manifest.md) |
| P002 | warn | no pinned dependency lock | `pip freeze > requirements.txt`, or uv/poetry lock |
| P003 | warn | no README | document run steps, software versions, data provenance |
| P004 | error | entry script missing | fix `command` |
| P005 | warn | notebook present | convert to a script run top-to-bottom |
| P006 | info | non-Python code present | not scanned in v0.1 |

## Stata (text patterns on .do/.ado; comments stripped)

| ID | Sev | Meaning |
|---|---|---|
| ST001 | error | random commands/functions (`runiform`, `bsample`, `bootstrap`, `simulate`, ...) but no `set seed` anywhere |
| ST002 | warn | no `version` statement in any do-file |
| ST003 | warn | absolute path |
| ST004 | warn | `merge m:m` |
| ST005 | info | `sort` without `, stable` |
| ST006 | warn | `ssc install` / `net install` at run time (unpinned versions) |
| ST007 | warn | `capture` that may hide an error |
| ST008 | warn | `browse` / `edit` in batch code |
| ST009 | warn | result-like name assigned a hard-coded number |

## R (text patterns on .R/.Rmd/.qmd)

| ID | Sev | Meaning |
|---|---|---|
| RR001 | error | random functions but no `set.seed` anywhere |
| RR002 | warn | absolute path / setwd to one |
| RR003 | warn | no renv.lock |
| RR004 | warn | install.packages / install_github in scripts |
| RR005 | warn | error swallowed (`try(silent=TRUE)`, `tryCatch` returning NULL/NA) |
| RR006 | error | `readline` / `browser()` / `file.choose` / `menu` |
| RR007 | warn | parallel code without reproducible RNG setup |
| RR008 | warn | result-like name assigned a hard-coded number |
| RR009 | warn | `Sys.time()` / `Sys.Date()` |

## Sample flow (from the pandas tracer)

| ID | Sev | Meaning |
|---|---|---|
| TR001 | warn | left/inner merge/join returned more rows than the left table (duplicate keys on the right) |
| TR002 | warn | dropna / drop_duplicates / query / boolean filter removed more than 20% of rows |
| TR003 | warn | inner merge lost more than 20% of left rows |

These are prompts for the author to explain, not errors in themselves. `check` fails only if the flow differs from the baseline.

## Table consistency and paper claims (v0.3)

| ID | Sev | Meaning |
|---|---|---|
| TB001 | warn | `t` column differs from `coef/se` beyond rounding tolerance |
| TB002 | warn | `p` column smaller than the normal-approximation p for that `t` (a t-distribution can only give a larger p) |
| (claim) | FAIL in `check` | a `[[claims]]` number does not match the output cell, or its file/row/column cannot be found |

## Provenance (heuristic; never FAIL)

| ID | Sev | Meaning |
|---|---|---|
| ORPH001 | warn | file in an output location that the pipeline did not regenerate |
| FIG001 | warn | AI-generation indicator in image metadata (e.g. IPTC trainedAlgorithmicMedia, generator names) |
| FIG002 | info | no recognisable plotting-software producer in metadata |
| FIG004 | info | C2PA / content-credentials data present (not by itself AI-generated) |
| DISC001 | warn | declared no AI use, but AI-related text mentions or git co-author trailers found |
| DISC002 | info | AI signals found, no `[disclosure]` section |
| DISC003 | info | AI use declared without `tools`/`scope` |
| DISC004 | info | AI use declared; no independent signals |
| DISC005 | warn | placeholder-like strings in code (`path/to/`, `your_file`, ...) |

Limits: rules are syntactic heuristics (single-file AST). Seed detection is project-wide, so a seed set in one module counts for the whole project. Torch/TensorFlow seeding is not checked. A clean scan does not prove reproducibility; the baseline's two-environment run is the real test.
