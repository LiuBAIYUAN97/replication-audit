# repro.toml

```toml
[project]
name = "my-paper"
command = ["python", "run_all.py"]   # one entry point, run from the project root
timeout_seconds = 900
# copy_exclude = ["big_cache"]        # file/folder NAMES not copied into the clean run copies

[env]                                  # optional: author-pinned environment variables
# PYTHONHASHSEED = "0"                 # pinned keys are NOT varied in the perturbed run

[inputs]
files = ["data/raw/*.csv"]             # globs, hashed; changes are reported by `check`

[tolerance]                            # defaults for numeric comparison
rel_tol = 1e-6
abs_tol = 1e-9

[[outputs]]
path = "output/table1_main.csv"
exact_columns = ["n"]                  # columns that must match exactly (counts, sample sizes)

[[outputs]]
path = "output/table2_robust.csv"
rel_tol = 1e-4                         # per-output override; justify it in the README

[[outputs]]
path = "output/fig1.png"
compare = "none"                       # recorded only; compare the figure's data file instead
```

`compare` values: `auto` (default; .csv/.tsv -> table, .json -> json, else exact bytes), `table`, `json`, `exact`, `none`.

Rules of thumb for tolerances: counts exact; regression coefficients and standard errors 1e-6 relative; bootstrap/simulation/optimiser outputs may need looser tolerances, and the reason should be written in the README.

Requirements for the entry script: non-interactive, writes only relative paths under the project root, creates its own output folders, and sets every random seed explicitly.

How runs are controlled: a clean copy of the project is made; declared outputs are deleted first so stale files cannot pass; `python` in `command` is replaced by the interpreter running the audit; `PYTHONHASHSEED=0`, single-threaded BLAS, `MPLBACKEND=Agg`, `TZ=UTC` are set. The perturbed run changes hash seed, thread count and time zone (unless pinned in `[env]`) and uses a path containing a space.


## Optional sections (v0.2)

```toml
[trace]
enabled = true            # default; pandas sample-flow tracing when command is ["python", "x.py", ...]

[artifacts]
globs = ["output/**/*"]   # default: the folder of each declared output. Files here are DELETED in the
                          # run copies; any that the pipeline does not regenerate are reported as orphans.
strict = false            # true: an orphan makes `check` FAIL
# globs = []              # disable the orphan check (e.g. if the pipeline needs pre-existing files there)

[env_capture]             # record non-Python tool versions; differences are listed by `check`
command = ["Rscript", "-e", "sessionInfo()"]      # Stata: a do-file that runs `about` / `which` and displays versions

[disclosure]              # compared with independent signals by `provenance` (heuristic)
ai_used = "yes"           # "yes" | "no" | "undeclared"
tools = ["ChatGPT", "Claude"]
scope = "code drafting; all code reviewed and run by the authors"
```

Non-Python entries: `command = ["Rscript", "run_all.R"]` or `command = ["stata", "-b", "do", "main.do"]` (use your Stata executable). Everything except sample-flow tracing works the same way.

Draft a manifest automatically: `python scripts/audit.py init ROOT`.

## Paper claims (v0.3)

List numbers as printed in the paper; `check` verifies each against the fresh outputs and FAILs on a mismatch.

```toml
[[claims]]
id = "main_effect"
paper = "Table 2, column 1"          # free text: where it appears in the paper
file = "output/table1_main.csv"
select = { term = "treat" }          # row filter, all pairs must match exactly one row
column = "coef"
value = "0.504"                      # as printed; a string keeps trailing zeros ("0.50" => 2 decimals)

[[claims]]
id = "sample_size"
paper = "Table 2, N"
file = "output/table1_main.csv"
select = { term = "const" }
column = "n"
value = 400                          # integer => compared at 0 decimals

# optional per claim: decimals = 3   or   abs_tol = 0.0005
```

Rounding is half-up on the exact output value at the printed number of decimals. Percentages and stars are not parsed; claim the underlying number.

Regression-table consistency (TB001 t differs from coef/se; TB002 p smaller than any t-distribution allows for that t) runs automatically on declared CSV outputs that have columns named like coef/estimate/beta, se/stderr, t/tstat, p/pval.
