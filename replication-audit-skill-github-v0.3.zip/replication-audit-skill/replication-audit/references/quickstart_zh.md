# 快速上手（中文）

需要 Python 3.11 及以上（只运行本工具；被审计项目自己的依赖另装）。以下命令均在本 skill 目录下执行，`ROOT` 是你的复现包文件夹。

## 先用 demo 熟悉一遍
```
python tests/make_demo.py /tmp/demo        # 生成 good / bad / flow 三个示例包（需要 numpy pandas matplotlib）
python scripts/audit.py scan     /tmp/demo/bad     # 看静态扫描能抓到什么
python scripts/audit.py baseline /tmp/demo/bad     # 未设随机种子 -> UNSTABLE，拒绝保存基线
python scripts/audit.py baseline /tmp/demo/flow    # 稳定，并列出样本流与提示
python scripts/audit.py check    /tmp/demo/flow    # 重跑并与基线比对
```

## 用在自己的复现包上
1. `python scripts/audit.py init ROOT`：生成 `repro.toml` 草稿，**逐行核对**（入口命令、输入、输出、容差）。
2. `python scripts/audit.py scan ROOT`：先修 error，再和作者讨论 warn。
3. `python scripts/audit.py baseline ROOT`：两次受控运行，稳定才保存基线。
4. 在 `repro.toml` 里按论文写 `[[claims]]`（见 manifest.md），把论文里印出来的关键数字登记进去。
5. `python scripts/audit.py check ROOT`：以后每次改动、换电脑、换 agent 都跑一遍。
6. `python scripts/audit.py provenance ROOT --with-run`：图像元数据、孤立文件、AI 披露一致性（启发式，只供人工复核）。

在另一台电脑或另一个 agent 上验证：把整个文件夹（含 `repro_baseline/`）拷过去，运行同一条 `check`。

## 结果怎么读
- `PASS`：在测试环境内复现了自己的基线；不代表分析正确。
- `FAIL`：看报告指出的具体文件、单元格、样本流步骤或论文声明。
- `UNSTABLE`：同一代码在两个受控环境结果不同，先找随机性、顺序、线程、路径问题。
- 报告在 `repro_report.md`（给人看）和 `repro_report.json`（给程序看）。
