"""Paper-vs-output claim checks and regression-table internal consistency.
Standard library only.

Claims: the author lists numbers as printed in the paper and where they come from;
the audit verifies them against the freshly produced outputs.  This catches typed-in or
stale numbers (a typical failure of AI-assisted drafting) without trusting anyone's memory.
"""
import csv
import math
import os
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

COEF_NAMES = {"coef", "coefficient", "beta", "estimate", "b"}
SE_NAMES = {"se", "stderr", "std_err", "std.err", "std_error", "stderror"}
T_NAMES = {"t", "tstat", "t_stat", "t-stat", "t_value", "tvalue", "t-value"}
P_NAMES = {"p", "pval", "p_value", "pvalue", "p-value", "prob"}


def _read_csv(path):
    delim = "\t" if path.lower().endswith(".tsv") else ","
    with open(path, newline="", encoding="utf-8-sig") as fh:
        rows = list(csv.reader(fh, delimiter=delim))
    return (rows[0], rows[1:]) if rows else ([], [])


def _dec(x):
    try:
        return Decimal(str(x).strip())
    except InvalidOperation:
        return None


def validate_claims(raw):
    out = []
    for i, c in enumerate(raw, 1):
        for k in ("file", "column", "value"):
            if k not in c:
                raise ValueError(f"[[claims]] #{i} 缺少 {k}")
        out.append({"id": str(c.get("id", f"claim{i}")), "paper": str(c.get("paper", "")),
                    "file": str(c["file"]).replace("\\", "/"), "select": {str(k): str(v) for k, v in c.get("select", {}).items()},
                    "column": str(c["column"]), "value": c["value"],
                    "decimals": c.get("decimals"), "abs_tol": c.get("abs_tol")})
    return out


def evaluate_claims(claims, outdir):
    results = []
    for c in claims:
        r = {"id": c["id"], "paper": c["paper"], "file": c["file"], "column": c["column"],
             "claimed": str(c["value"]), "actual": None, "status": "error", "problem": ""}
        path = os.path.join(outdir, c["file"])
        if not os.path.exists(path):
            r["problem"] = "输出文件不存在"
            results.append(r)
            continue
        try:
            head, rows = _read_csv(path)
            if c["column"] not in head:
                r["problem"] = f"没有列 '{c['column']}'（现有列：{head}）"
                results.append(r)
                continue
            miss = [k for k in c["select"] if k not in head]
            if miss:
                r["problem"] = f"选择条件的列不存在：{miss}"
                results.append(r)
                continue
            idx = {k: head.index(k) for k in c["select"]}
            hit = [row for row in rows if all(row[idx[k]].strip() == v for k, v in c["select"].items())]
            if len(hit) != 1:
                r["problem"] = f"选择条件匹配到 {len(hit)} 行（应为 1 行）"
                results.append(r)
                continue
            actual = _dec(hit[0][head.index(c["column"])])
            claimed = _dec(c["value"])
            if actual is None or claimed is None:
                r["problem"] = "单元格或声明值不是数字"
                results.append(r)
                continue
            r["actual"] = str(actual)
            if c.get("abs_tol") is not None:
                ok = abs(actual - claimed) <= Decimal(str(c["abs_tol"]))
            else:
                dp = c["decimals"] if c.get("decimals") is not None else max(0, -claimed.as_tuple().exponent)
                q = Decimal(1).scaleb(-dp)
                ok = actual.quantize(q, rounding=ROUND_HALF_UP) == claimed.quantize(q, rounding=ROUND_HALF_UP)
                r["decimals_used"] = dp
            r["status"] = "pass" if ok else "fail"
            if not ok:
                r["problem"] = "论文数字与代码输出不一致"
        except Exception as e:  # malformed file etc.
            r["problem"] = f"读取失败：{e}"
        results.append(r)
    return results


def _col(head, names):
    low = [h.strip().lower() for h in head]
    for n in names:
        if n in low:
            return low.index(n)
    return None


def table_consistency(paths, outdir):
    """paths: relative CSV output paths.  Returns findings (warn) for internally inconsistent rows."""
    findings = []
    for rel in paths:
        if not rel.lower().endswith((".csv", ".tsv")):
            continue
        p = os.path.join(outdir, rel)
        if not os.path.exists(p):
            continue
        try:
            head, rows = _read_csv(p)
        except Exception:
            continue
        ic, ise, it, ip = (_col(head, S) for S in (COEF_NAMES, SE_NAMES, T_NAMES, P_NAMES))
        for n, row in enumerate(rows, 1):
            def num(i):
                try:
                    return float(row[i]) if i is not None else None
                except (ValueError, IndexError):
                    return None
            c, se, t, pv = num(ic), num(ise), num(it), num(ip)
            if None not in (c, se, t) and se != 0:
                if abs(t - c / se) > max(0.01, 0.01 * abs(t)):
                    findings.append({"id": "TB001", "severity": "warn", "file": rel, "row": n,
                                     "message": f"t ({t:.4g}) differs from coef/se ({c / se:.4g})."})
            if t is not None and pv is not None:
                p_norm = math.erfc(abs(t) / math.sqrt(2))
                if pv < p_norm - max(0.005, 0.05 * p_norm):
                    findings.append({"id": "TB002", "severity": "warn", "file": rel, "row": n,
                                     "message": f"p ({pv:.4g}) is smaller than any t-distribution allows for t={t:.4g} (normal-approx p={p_norm:.4g})."})
    return findings
