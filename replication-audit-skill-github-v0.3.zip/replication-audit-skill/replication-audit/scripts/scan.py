#!/usr/bin/env python3
"""Static scan of a Python replication package for sources of non-reproducibility
and common AI-code error patterns.  Standard library only (Python >= 3.11).

Usage:  python scan.py [PROJECT_ROOT] [--json OUT.json]
Exit code: 0 = no errors, 1 = at least one error-level finding.
"""
import argparse
import ast
import json
import os
import re
import sys

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    sys.exit("Python >= 3.11 is required (tomllib).")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import scan_other  # noqa: E402

SKIP_DIRS = {".git", "__pycache__", ".venv", "venv", "env", "node_modules",
             "repro_baseline", ".repro_work", "site-packages", ".ipynb_checkpoints"}

NP_SAMPLERS = {"rand", "randn", "randint", "random", "random_sample", "normal", "uniform",
               "choice", "shuffle", "permutation", "binomial", "poisson", "exponential",
               "standard_normal", "multivariate_normal", "beta", "gamma", "lognormal"}
PY_SAMPLERS = {"random", "randint", "choice", "choices", "shuffle", "sample", "uniform",
               "gauss", "randrange", "normalvariate"}
RANDOM_STATE_CALLS = {"train_test_split", "RandomForestClassifier", "RandomForestRegressor",
                      "ExtraTreesClassifier", "ExtraTreesRegressor", "GradientBoostingClassifier",
                      "GradientBoostingRegressor", "KMeans", "MiniBatchKMeans", "TSNE",
                      "MLPClassifier", "MLPRegressor", "SGDClassifier", "SGDRegressor",
                      "ShuffleSplit", "StratifiedShuffleSplit", "BaggingClassifier",
                      "BaggingRegressor", "GaussianMixture"}
TIME_CALLS = {"datetime.datetime.now", "datetime.datetime.today", "datetime.date.today",
              "datetime.datetime.utcnow", "time.time"}
ABS_PATH_RE = re.compile(r"^(?:/(?:Users|home|mnt|Volumes|var|tmp|opt)/|[A-Za-z]:[\\/]|\\\\)")
RESULT_NAME_RE = re.compile(
    r"(^|_)(coef|coeff|beta|se|stderr|pval|pvalue|p_value|tstat|t_stat|effect|estimate|"
    r"rsquared|r2|elasticity|ate|att)(_|$)", re.I)

RULES = {
    "R001": ("error", "Global numpy RNG used but no seed is set anywhere in the project, or an RNG is created without a seed."),
    "R002": ("error", "Standard-library `random` used but `random.seed(...)` is never called in the project."),
    "R003": ("warn", "Stochastic estimator/splitter called without `random_state`."),
    "R004": ("warn", "`.sample(...)` called without `random_state`."),
    "R005": ("warn", "Absolute / machine-specific path literal."),
    "R006": ("warn", "Depends on the current working directory (os.chdir / os.getcwd)."),
    "R007": ("error", "Interactive call that blocks unattended runs (`input()`)."),
    "R008": ("warn", "Output may depend on the wall clock (now/today/time)."),
    "R009": ("warn", "`merge` without `validate=`; silent row duplication is possible."),
    "R010": ("info", "`sort_values` without a stable `kind`; ties may be ordered differently."),
    "R011": ("warn", "Result-like variable assigned a hard-coded number (possible pasted/hallucinated result)."),
    "R012": ("info", "matplotlib used without selecting a non-interactive backend."),
    "R013": ("warn", "`plt.show()` blocks unattended runs; save the figure instead."),
    "R014": ("warn", "Exception silently swallowed (`except ...: pass`); failures can vanish."),
    "R015": ("error", "File could not be parsed."),
    "P001": ("error", "No readable repro.toml manifest at project root."),
    "P002": ("warn", "No pinned dependency lock (requirements.txt with == pins, uv.lock, poetry.lock, ...)."),
    "P003": ("warn", "No README at project root."),
    "P004": ("error", "Entry script declared in repro.toml does not exist."),
    "P005": ("warn", "Notebook found; hidden state and execution order are not auditable in v0.1."),
    "P006": ("info", "SAS/Matlab code found; not scanned (Python, Stata and R are)."),
}
RULES.update(scan_other.RULES_OTHER)
ENTRY_EXT = (".py", ".r", ".do", ".sh", ".rmd", ".qmd")


def iter_files(root):
    for dp, dns, fns in os.walk(root):
        dns[:] = sorted(d for d in dns if d not in SKIP_DIRS)
        for fn in sorted(fns):
            yield os.path.join(dp, fn)


def dotted(node):
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return None


class FileScanner(ast.NodeVisitor):
    def __init__(self, rel):
        self.rel = rel
        self.alias = {}
        self.findings = []
        self.np_samplers = []
        self.py_samplers = []
        self.np_seeded = False
        self.py_seeded = False
        self.uses_pyplot = False
        self.sets_backend = False

    def add(self, rid, node, extra=""):
        sev, msg = RULES[rid]
        self.findings.append({"id": rid, "severity": sev, "file": self.rel,
                              "line": getattr(node, "lineno", 0),
                              "message": msg + (f" [{extra}]" if extra else "")})

    def canon(self, node):
        d = dotted(node)
        if not d:
            return None
        head, _, rest = d.partition(".")
        if head in self.alias:
            head = self.alias[head]
        return head + ("." + rest if rest else "")

    def visit_Import(self, node):
        for a in node.names:
            if a.asname:
                self.alias[a.asname] = a.name
            else:
                top = a.name.split(".")[0]
                self.alias[top] = top
            if a.name.startswith("matplotlib.pyplot"):
                self.uses_pyplot = True

    def visit_ImportFrom(self, node):
        mod = node.module or ""
        for a in node.names:
            self.alias[a.asname or a.name] = f"{mod}.{a.name}" if mod else a.name
            if mod == "matplotlib" and a.name == "pyplot":
                self.uses_pyplot = True

    def visit_Call(self, node):
        c = self.canon(node.func) or ""
        last = c.rsplit(".", 1)[-1]
        kws = {k.arg for k in node.keywords if k.arg}
        none_arg = bool(
            (node.args and isinstance(node.args[0], ast.Constant) and node.args[0].value is None)
            or any(k.arg == "seed" and isinstance(k.value, ast.Constant) and k.value.value is None
                   for k in node.keywords))

        if c.startswith("matplotlib.pyplot"):
            self.uses_pyplot = True
        if c == "matplotlib.use":
            self.sets_backend = True
        if c == "matplotlib.pyplot.show":
            self.add("R013", node)

        if c == "numpy.random.seed":
            self.np_seeded = True
        elif c in ("numpy.random.default_rng", "numpy.random.RandomState", "random.Random"):
            if (not node.args and not node.keywords) or none_arg:
                self.add("R001", node, f"{last}() without seed")
            elif c.startswith("numpy"):
                self.np_seeded = True
            else:
                self.py_seeded = True
        elif c.startswith("numpy.random.") and last in NP_SAMPLERS:
            self.np_samplers.append(node)
        elif c == "random.seed":
            self.py_seeded = True
        elif c.startswith("random.") and last in PY_SAMPLERS:
            self.py_samplers.append(node)

        if last in RANDOM_STATE_CALLS:
            rs = [k for k in node.keywords if k.arg == "random_state"]
            if not rs or (isinstance(rs[0].value, ast.Constant) and rs[0].value.value is None):
                self.add("R003", node, last)
        if isinstance(node.func, ast.Attribute):
            attr = node.func.attr
            if attr == "sample" and not c.startswith("random.") and "random_state" not in kws:
                self.add("R004", node)
            if attr == "merge" and "validate" not in kws:
                self.add("R009", node)
            if attr == "sort_values" and "kind" not in kws:
                self.add("R010", node)
        if c in ("os.chdir", "os.getcwd"):
            self.add("R006", node, c)
        if c == "input":
            self.add("R007", node)
        if c in TIME_CALLS:
            self.add("R008", node, c)
        self.generic_visit(node)

    def visit_Constant(self, node):
        if isinstance(node.value, str) and len(node.value) < 300 and ABS_PATH_RE.match(node.value):
            self.add("R005", node, node.value[:60])

    def visit_Assign(self, node):
        v = node.value
        if isinstance(v, ast.UnaryOp) and isinstance(v.op, (ast.USub, ast.UAdd)):
            v = v.operand
        if isinstance(v, ast.Constant) and isinstance(v.value, float) and round(v.value, 2) != v.value:
            for t in node.targets:
                if isinstance(t, ast.Name) and RESULT_NAME_RE.search(t.id):
                    self.add("R011", node, f"{t.id} = {v.value}")
        self.generic_visit(node)

    def visit_ExceptHandler(self, node):
        broad = node.type is None or self.canon(node.type) in ("Exception", "BaseException")
        silent = all(isinstance(s, (ast.Pass, ast.Continue)) for s in node.body)
        if broad and silent:
            self.add("R014", node)
        self.generic_visit(node)


def lock_status(root):
    for name in ("uv.lock", "poetry.lock", "Pipfile.lock", "conda-lock.yml", "pixi.lock"):
        if os.path.exists(os.path.join(root, name)):
            return True
    req = os.path.join(root, "requirements.txt")
    if os.path.exists(req):
        with open(req, encoding="utf-8") as fh:
            lines = [l.strip() for l in fh if l.strip() and not l.strip().startswith(("#", "-"))]
        return bool(lines) and all("==" in l for l in lines)
    return False


def scan(root):
    root = os.path.abspath(root)
    findings, np_users, py_users = [], [], []
    np_seeded = py_seeded = False
    uses_pyplot = sets_backend = False
    pyfiles = 0
    other_code, notebooks = [], []
    agg = {k: {"files": 0, "seed": False, "version": False, "parallel": False,
               "parallel_ok": False, "random": []} for k in ("stata", "r")}

    for path in iter_files(root):
        rel = os.path.relpath(path, root).replace(os.sep, "/")
        ext = os.path.splitext(path)[1].lower()
        if ext == ".ipynb":
            notebooks.append(rel)
        elif ext in (".sas", ".m"):
            other_code.append(rel)
        elif ext in (".do", ".ado", ".r", ".rmd", ".qmd"):
            kind = "stata" if ext in (".do", ".ado") else "r"
            try:
                with open(path, encoding="utf-8", errors="replace") as fh:
                    ff, fl = scan_other.scan_text(rel, fh.read(), kind)
            except OSError:
                continue
            findings += ff
            agg[kind]["files"] += 1
            agg[kind]["seed"] |= fl["seed"]
            agg[kind]["version"] |= fl["version"]
            agg[kind]["parallel"] |= fl["parallel"]
            agg[kind]["parallel_ok"] |= fl["parallel_ok"]
            agg[kind]["random"] += [(rel, n) for n in fl["random_lines"]]
        if ext != ".py":
            continue
        pyfiles += 1
        try:
            with open(path, encoding="utf-8") as fh:
                tree = ast.parse(fh.read(), filename=rel)
        except (SyntaxError, UnicodeDecodeError) as e:
            findings.append({"id": "R015", "severity": "error", "file": rel,
                             "line": getattr(e, "lineno", 0) or 0, "message": RULES["R015"][1]})
            continue
        fs = FileScanner(rel)
        fs.visit(tree)
        findings += fs.findings
        np_seeded |= fs.np_seeded
        py_seeded |= fs.py_seeded
        uses_pyplot |= fs.uses_pyplot
        sets_backend |= fs.sets_backend
        np_users += [(rel, n) for n in fs.np_samplers]
        py_users += [(rel, n) for n in fs.py_samplers]

    def proj(rid, file, line=0, extra=""):
        sev, msg = RULES[rid]
        findings.append({"id": rid, "severity": sev, "file": file, "line": line,
                         "message": msg + (f" [{extra}]" if extra else "")})

    if not np_seeded:
        for rel, n in np_users:
            proj("R001", rel, n.lineno, "global numpy sampler, no seed anywhere")
    if not py_seeded:
        for rel, n in py_users:
            proj("R002", rel, n.lineno, "stdlib random sampler, no seed anywhere")
    st, rr = agg["stata"], agg["r"]
    if st["files"]:
        if not st["seed"]:
            for rel, ln in st["random"]:
                proj("ST001", rel, ln)
        if not st["version"]:
            proj("ST002", ".")
    if rr["files"]:
        if not rr["seed"]:
            for rel, ln in rr["random"]:
                proj("RR001", rel, ln)
        if not os.path.exists(os.path.join(root, "renv.lock")):
            proj("RR003", ".")
        if rr["parallel"] and not rr["parallel_ok"]:
            proj("RR007", ".")
    if uses_pyplot and not sets_backend:
        proj("R012", ".", 0, "audited runs set MPLBACKEND=Agg")
    for nb in notebooks:
        proj("P005", nb)
    for oc in other_code:
        proj("P006", oc)

    mpath = os.path.join(root, "repro.toml")
    if not os.path.exists(mpath):
        proj("P001", "repro.toml")
    else:
        try:
            with open(mpath, "rb") as fh:
                man = tomllib.load(fh)
            cmd = man.get("project", {}).get("command", [])
            scripts = [c for c in cmd if str(c).lower().endswith(ENTRY_EXT)]
            if not scripts or not all(os.path.exists(os.path.join(root, s)) for s in scripts):
                proj("P004", "repro.toml", 0, " ".join(map(str, cmd)))
        except Exception as e:
            proj("P001", "repro.toml", 0, f"unreadable: {e}")
    if not lock_status(root):
        proj("P002", ".")
    if not any(os.path.exists(os.path.join(root, n)) for n in ("README.md", "README.txt", "README", "readme.md")):
        proj("P003", ".")

    findings.sort(key=lambda f: (f["file"], f["line"], f["id"]))
    counts = {s: sum(1 for f in findings if f["severity"] == s) for s in ("error", "warn", "info")}
    verdict = "FAIL" if counts["error"] else ("PASS_WITH_WARNINGS" if counts["warn"] else "PASS")
    return {"tool": "replication-audit/scan", "python_files_scanned": pyfiles,
            "summary": counts, "verdict": verdict, "findings": findings}


def print_report(rep):
    w = sys.stdout.write
    s = rep["summary"]
    w(f"静态扫描：{rep['python_files_scanned']} 个 Python 文件；error={s['error']} warn={s['warn']} info={s['info']}\n")
    for f in rep["findings"]:
        w(f"  [{f['severity'].upper():5}] {f['id']} {f['file']}:{f['line']}  {f['message']}\n")
    w(f"结论：{rep['verdict']}\n")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--json", dest="json_out")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    rep = scan(a.root)
    print_report(rep)
    if a.json_out:
        with open(a.json_out, "w", encoding="utf-8") as fh:
            json.dump(rep, fh, ensure_ascii=False, indent=2, sort_keys=True)
    return 1 if rep["summary"]["error"] else 0


if __name__ == "__main__":
    sys.exit(main())
