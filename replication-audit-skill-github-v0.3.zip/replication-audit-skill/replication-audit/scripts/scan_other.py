"""Line-based static rules for Stata (.do/.ado) and R (.R/.Rmd/.qmd) code.
These are text heuristics (no Stata/R needed to run them).  Standard library only."""
import re

RULES_OTHER = {
    "ST001": ("error", "Stata: random commands/functions used but `set seed` never appears in the project."),
    "ST002": ("warn", "Stata: no `version` statement in any do-file; default behaviour changes between releases."),
    "ST003": ("warn", "Stata: absolute / machine-specific path."),
    "ST004": ("warn", "Stata: `merge m:m` (almost never what is intended; order-dependent)."),
    "ST005": ("info", "Stata: `sort` without `, stable`; ties may be ordered differently."),
    "ST006": ("warn", "Stata: user-written package installed at run time (`ssc/net install`); versions drift. Record versions or ship the ado files."),
    "ST007": ("warn", "Stata: `capture` may hide an error; use `capture noisily` or check `_rc`."),
    "ST008": ("warn", "Stata: `browse`/`edit` blocks unattended batch runs."),
    "ST009": ("warn", "Stata: result-like name assigned a hard-coded number."),
    "RR001": ("error", "R: random functions used but `set.seed` never appears in the project."),
    "RR002": ("warn", "R: absolute / machine-specific path (or setwd to one)."),
    "RR003": ("warn", "R: no renv.lock; package versions are not pinned."),
    "RR004": ("warn", "R: packages installed at run time (install.packages / install_github)."),
    "RR005": ("warn", "R: error swallowed (try(silent=TRUE) / tryCatch returning NULL/NA)."),
    "RR006": ("error", "R: interactive call blocks unattended runs (readline/browser/file.choose/menu)."),
    "RR007": ("warn", "R: parallel code without a reproducible RNG setup (L'Ecuyer / future.seed / mc.set.seed)."),
    "RR008": ("warn", "R: result-like name assigned a hard-coded number."),
    "RR009": ("warn", "R: output may depend on the wall clock (Sys.time/Sys.Date)."),
}

ABS = r"(?:(?<![A-Za-z])[A-Za-z]:[\\/]|/Users/|/home/|/Volumes/|/mnt/|~/)"
ST_RANDOM_FN = re.compile(r"\b(runiform|rnormal|rbinomial|rpoisson|rexponential|rchi2|rgamma|rbeta|rt|rlogistic)\s*\(")
ST_RANDOM_CMD = re.compile(r"^\s*(bsample|bootstrap|simulate|sample|splitsample|permute)\b|vce\(\s*boot")
ST_SEED = re.compile(r"\bset\s+seed\b")
ST_VERSION = re.compile(r"^\s*version\s+\d")
ST_ABS = re.compile(ABS)
ST_MM = re.compile(r"\bmerge\s+m:m\b")
ST_SORT = re.compile(r"^\s*sort\s+\S")
ST_INSTALL = re.compile(r"^\s*(ssc\s+install|net\s+install|net\s+get|adoupdate|ado\s+update)\b")
ST_CAPTURE = re.compile(r"^\s*(cap|capt|captu|captur|capture)\s+(?!noisily\b|drop\b|confirm\b|log\b|mkdir\b|erase\b|rm\b|label\b|cd\b)")
ST_BROWSE = re.compile(r"^\s*(browse|edit)\b")
ST_HARD = re.compile(r"(?i)^\s*(?:gen(?:erate)?|scalar|replace)\s+(?:\w+\s+)?\w*(coef|beta|_se|pval|tstat|effect|estimate)\w*\s*=\s*-?\d+\.\d{3,}\b")

R_RANDOM = re.compile(r"\b(rnorm|runif|rbinom|rpois|rexp|rgamma|rbeta|rt|rchisq|sample|sample_n|sample_frac|slice_sample|createDataPartition)\s*\(")
R_SEED = re.compile(r"\bset\.seed\s*\(")
R_ABS = re.compile(r"[\"']" + ABS)
R_INSTALL = re.compile(r"\b(install\.packages|install_github|install_version|install_gitlab)\s*\(")
R_SWALLOW = re.compile(r"\btry\s*\(.*silent\s*=\s*TRUE|error\s*=\s*function\s*\([^)]*\)\s*(NULL|NA|invisible\(\))")
R_BLOCK = re.compile(r"\b(readline|file\.choose|menu)\s*\(|\bbrowser\s*\(\s*\)")
R_PAR = re.compile(r"\b(mclapply|parLapply|parSapply|foreach|future_map|future_lapply|%dopar%)")
R_PAR_OK = re.compile(r"L'Ecuyer|future\.seed|mc\.set\.seed|clusterSetRNGStream|\.options\.RNG|doRNG")
R_HARD = re.compile(r"(?i)^\s*\w*(coef|beta|_se|pval|tstat|effect|estimate)\w*\s*(<-|=)\s*-?\d+\.\d{3,}\b")
R_TIME = re.compile(r"\bSys\.(time|Date)\s*\(")


def _strip_stata(lines):
    out, in_block = [], False
    for i, ln in enumerate(lines, 1):
        s = ln
        if in_block:
            if "*/" in s:
                s = s.split("*/", 1)[1]
                in_block = False
            else:
                continue
        while "/*" in s:
            pre, _, post = s.partition("/*")
            if "*/" in post:
                s = pre + " " + post.split("*/", 1)[1]
            else:
                s = pre
                in_block = True
                break
        if s.lstrip().startswith("*"):
            continue
        s = re.sub(r"(^|\s)//.*$", "", s)
        if s.strip():
            out.append((i, s))
    return out


def _strip_r(lines):
    out = []
    for i, ln in enumerate(lines, 1):
        s = re.sub(r"(^|\s)#.*$", "", ln) if not re.search(r"[\"'].*#.*[\"']", ln) else ln
        if s.strip():
            out.append((i, s))
    return out


def scan_text(rel, text, kind):
    """kind: 'stata' | 'r'.  Returns (findings, flags)."""
    lines = text.splitlines()
    F = []
    flags = {"seed": False, "random_lines": [], "version": False, "parallel": False,
             "parallel_ok": False, "lines": 0}

    def add(rid, ln, extra=""):
        sev, msg = RULES_OTHER[rid]
        F.append({"id": rid, "severity": sev, "file": rel, "line": ln,
                  "message": msg + (f" [{extra}]" if extra else "")})

    if kind == "stata":
        for ln, s in _strip_stata(lines):
            flags["lines"] += 1
            if ST_SEED.search(s):
                flags["seed"] = True
            if ST_VERSION.search(s):
                flags["version"] = True
            if ST_RANDOM_FN.search(s) or ST_RANDOM_CMD.search(s):
                flags["random_lines"].append(ln)
            if ST_ABS.search(s) and "://" not in s:
                add("ST003", ln, s.strip()[:60])
            if ST_MM.search(s):
                add("ST004", ln)
            if ST_SORT.search(s) and "stable" not in s:
                add("ST005", ln)
            if ST_INSTALL.search(s):
                add("ST006", ln, s.strip()[:60])
            if ST_CAPTURE.search(s):
                add("ST007", ln, s.strip()[:60])
            if ST_BROWSE.search(s):
                add("ST008", ln)
            if ST_HARD.search(s):
                add("ST009", ln, s.strip()[:60])
    else:
        for ln, s in _strip_r(lines):
            flags["lines"] += 1
            if R_SEED.search(s):
                flags["seed"] = True
            if R_RANDOM.search(s):
                flags["random_lines"].append(ln)
            if R_ABS.search(s):
                add("RR002", ln, s.strip()[:60])
            if R_INSTALL.search(s):
                add("RR004", ln)
            if R_SWALLOW.search(s):
                add("RR005", ln)
            if R_BLOCK.search(s):
                add("RR006", ln)
            if R_PAR.search(s):
                flags["parallel"] = True
            if R_PAR_OK.search(s):
                flags["parallel_ok"] = True
            if R_HARD.search(s):
                add("RR008", ln, s.strip()[:60])
            if R_TIME.search(s):
                add("RR009", ln)
    return F, flags
