#!/usr/bin/env python3
"""replication-audit CLI (standard library only, Python >= 3.11).

  audit.py init       [ROOT] [--force]       draft a repro.toml from what is in the folder
  audit.py scan       [ROOT]                 static scan (Python, Stata, R) for non-reproducibility sources
  audit.py baseline   [ROOT] [--force]       run twice (controlled + perturbed env); if stable, store baseline
  audit.py check      [ROOT] [--outputs DIR] re-run in a clean copy (or read DIR) and compare to baseline
  audit.py provenance [ROOT] [--with-run]    figure metadata + AI-disclosure consistency (heuristic)

All pass/fail decisions are made here, by code.  An agent must not edit the baseline,
the manifest tolerances or the analysis code in order to make a check pass.

Exit codes: 0 pass | 1 fail | 2 unstable (baseline refused) | 3 usage/setup error
"""
import argparse
import csv
import glob
import hashlib
import json
import math
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from importlib import metadata

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    sys.exit("Python >= 3.11 is required (tomllib).")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import claims as claims_mod  # noqa: E402
import provenance as prov_mod  # noqa: E402
import scan as scan_mod  # noqa: E402

BASELINE_DIR = "repro_baseline"
REPORT_FILE = "repro_report.json"
BASE_IGNORE = (".git", "__pycache__", ".venv", "venv", "node_modules", BASELINE_DIR, ".repro_work",
               REPORT_FILE, "repro_report.md", "repro_provenance.json")
WRAP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trace_wrap.py")
VERSION = "0.3"
DEFAULT_REL, DEFAULT_ABS = 1e-6, 1e-9

CONTROLLED_ENV = {
    "PYTHONHASHSEED": "0", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1",
    "MPLBACKEND": "Agg", "TZ": "UTC", "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1",
}
PERTURBED_ENV = {
    "PYTHONHASHSEED": "4242", "OMP_NUM_THREADS": "2", "MKL_NUM_THREADS": "2",
    "OPENBLAS_NUM_THREADS": "2", "NUMEXPR_NUM_THREADS": "2", "TZ": "Asia/Shanghai",
}


class SetupError(Exception):
    pass


# ----------------------------------------------------------------- helpers
def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_manifest(root, required=True):
    path = os.path.join(root, "repro.toml")
    if not os.path.exists(path):
        if required:
            raise SetupError("找不到 repro.toml（可先运行 init 生成草稿；格式见 references/manifest.md）")
        return None
    try:
        with open(path, "rb") as fh:
            man = tomllib.load(fh)
    except Exception as e:
        raise SetupError(f"repro.toml 无法解析：{e}")
    proj = man.get("project", {})
    if required and not proj.get("command"):
        raise SetupError("repro.toml 缺少 [project].command")
    if required and not man.get("outputs"):
        raise SetupError("repro.toml 至少需要一个 [[outputs]]")
    tol = man.get("tolerance", {})
    specs = []
    for o in man.get("outputs", []):
        if "path" not in o:
            raise SetupError("每个 [[outputs]] 都需要 path")
        specs.append({
            "path": o["path"].replace("\\", "/"),
            "compare": o.get("compare", "auto"),
            "rel_tol": float(o.get("rel_tol", tol.get("rel_tol", DEFAULT_REL))),
            "abs_tol": float(o.get("abs_tol", tol.get("abs_tol", DEFAULT_ABS))),
            "exact_columns": list(o.get("exact_columns", [])),
        })
    try:
        claim_list = claims_mod.validate_claims(man.get("claims", []))
    except ValueError as e:
        raise SetupError(str(e))
    art = man.get("artifacts", {})
    if "globs" in art:
        globs = list(art["globs"])
    else:
        dirs = sorted({os.path.dirname(s["path"]) for s in specs if os.path.dirname(s["path"])})
        globs = [d + "/**/*" for d in dirs]
    return {"command": list(proj.get("command", [])), "timeout": int(proj.get("timeout_seconds", 900)),
            "env": {str(k): str(v) for k, v in man.get("env", {}).items()},
            "inputs": list(man.get("inputs", {}).get("files", [])), "outputs": specs,
            "copy_exclude": list(proj.get("copy_exclude", [])),
            "trace": bool(man.get("trace", {}).get("enabled", True)),
            "artifact_globs": globs, "artifacts_strict": bool(art.get("strict", False)),
            "env_capture": list(man.get("env_capture", {}).get("command", [])),
            "disclosure": dict(man.get("disclosure", {})), "claims": claim_list}


def artifact_files(base, globs):
    res = set()
    for g in globs:
        for p in glob.glob(os.path.join(base, g), recursive=True):
            if os.path.isfile(p):
                res.add(os.path.relpath(p, base).replace(os.sep, "/"))
    return res


def hash_inputs(root, patterns):
    res = {}
    for pat in patterns:
        hits = [p for p in glob.glob(os.path.join(root, pat), recursive=True) if os.path.isfile(p)]
        if not hits:
            raise SetupError(f"输入文件模式没有匹配到任何文件：{pat}")
        for p in hits:
            res[os.path.relpath(p, root).replace(os.sep, "/")] = sha256_file(p)
    return dict(sorted(res.items()))


def env_snapshot():
    pk = {}
    for d in metadata.distributions():
        n = (d.metadata["Name"] or "").lower()
        if n:
            pk[n] = d.version
    return {"python": platform.python_version(), "implementation": platform.python_implementation(),
            "platform": platform.platform(), "machine": platform.machine(), "packages": dict(sorted(pk.items()))}


def capture_tool_info(root, man):
    if not man.get("env_capture"):
        return None
    cmd = [sys.executable if c in ("python", "python3") else c for c in man["env_capture"]]
    try:
        r = subprocess.run(cmd, cwd=root, capture_output=True, text=True, timeout=120,
                           encoding="utf-8", errors="replace")
        return (r.stdout or r.stderr).strip()[:20000]
    except Exception as e:
        return f"(env_capture failed: {e})"


def env_diff(base, now):
    out = []
    if base["python"] != now["python"]:
        out.append(f"python: {base['python']} -> {now['python']}")
    if base["platform"] != now["platform"]:
        out.append(f"platform: {base['platform']} -> {now['platform']}")
    bp, np_ = base["packages"], now["packages"]
    for k in sorted(set(bp) | set(np_)):
        if bp.get(k) != np_.get(k):
            out.append(f"package {k}: {bp.get(k, '(absent)')} -> {np_.get(k, '(absent)')}")
    bt, nt = base.get("tool_info"), now.get("tool_info")
    if bt is not None and nt is not None and bt != nt:
        bl, nl = set(bt.splitlines()), set(nt.splitlines())
        out += [f"tool_info -: {x}" for x in sorted(bl - nl)[:10]] + [f"tool_info +: {x}" for x in sorted(nl - bl)[:10]]
    return out[:40]


def tail(text, n=15):
    return "\n".join(text.strip().splitlines()[-n:])


# ----------------------------------------------------------------- running
def build_command(man, trace_file):
    cmd = list(man["command"])
    exe = cmd[0]
    py = exe in ("python", "python3") or os.path.abspath(exe) == os.path.abspath(sys.executable)
    if py and man["trace"] and len(cmd) > 1 and cmd[1].lower().endswith(".py"):
        return [sys.executable, WRAP, *cmd[1:]], True
    return [sys.executable if py else exe, *cmd[1:]], False


def read_flow(path):
    flow = []
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                r = json.loads(line)
                if r.get("op") == "_unavailable":
                    return None
                flow.append({k: r[k] for k in ("op", "where", "rows_in", "rows_out", "how") if k in r})
    except OSError:
        return None
    return flow


def run_in_copy(root, man, perturbed, originals=None):
    work = tempfile.mkdtemp(prefix="repro_")
    dest = os.path.join(work, "x y", "pkg_perturbed") if perturbed else os.path.join(work, "pkg")
    shutil.copytree(root, dest, ignore=shutil.ignore_patterns(*BASE_IGNORE, *man["copy_exclude"]))
    for rel in artifact_files(dest, man["artifact_globs"]) | {s["path"] for s in man["outputs"]}:
        p = os.path.join(dest, rel)
        if os.path.isfile(p):
            os.remove(p)
    env = os.environ.copy()
    if perturbed:
        env.update({k: v for k, v in PERTURBED_ENV.items() if k not in man["env"]})
        env.update({k: v for k, v in CONTROLLED_ENV.items() if k not in PERTURBED_ENV})
        env.update(man["env"])
    else:
        env.update(CONTROLLED_ENV)
        env.update(man["env"])
    trace_file = os.path.join(work, "trace.jsonl")
    env["REPRO_TRACE_FILE"] = trace_file
    cmd, traced = build_command(man, trace_file)
    try:
        r = subprocess.run(cmd, cwd=dest, env=env, capture_output=True, text=True,
                           timeout=man["timeout"], encoding="utf-8", errors="replace")
        rc, err = r.returncode, r.stderr or r.stdout
    except subprocess.TimeoutExpired:
        rc, err = 124, f"timeout after {man['timeout']}s"
    produced = artifact_files(dest, man["artifact_globs"])
    orphans = sorted((originals or set()) - produced)
    flow = read_flow(trace_file) if traced else None
    return {"dir": dest, "work": work, "returncode": rc, "log_tail": tail(err), "flow": flow, "orphans": orphans}


def flow_flags(flow):
    out = []
    for i, e in enumerate(flow or [], 1):
        op, ri, ro = e["op"], e["rows_in"], e["rows_out"]
        if ro is None or not ri or ri[0] in (None, 0):
            continue
        if op in ("merge", "join"):
            how = e.get("how", "inner")
            if how in ("left", "inner") and ro > ri[0]:
                out.append({"id": "TR001", "severity": "warn", "step": i, "where": e["where"],
                            "message": f"{op} ({how}) increased rows {ri[0]} -> {ro}: duplicate keys on the right side?"})
            elif how == "inner" and ro < 0.8 * ri[0]:
                out.append({"id": "TR003", "severity": "warn", "step": i, "where": e["where"],
                            "message": f"inner {op} lost {100 * (1 - ro / ri[0]):.0f}% of left rows ({ri[0]} -> {ro})."})
        elif op in ("dropna", "drop_duplicates", "query", "filter_mask") and ro < 0.8 * ri[0]:
            out.append({"id": "TR002", "severity": "warn", "step": i, "where": e["where"],
                        "message": f"{op} dropped {100 * (1 - ro / ri[0]):.0f}% of rows ({ri[0]} -> {ro})."})
    return out


def compare_flow(base, new):
    sig = lambda f: [(e["op"], e["where"], tuple(e["rows_in"]), e["rows_out"]) for e in f]  # noqa: E731
    sb, sn = sig(base), sig(new)
    diffs = []
    for i in range(max(len(sb), len(sn))):
        x = sb[i] if i < len(sb) else None
        y = sn[i] if i < len(sn) else None
        if x != y:
            diffs.append({"step": i + 1, "baseline": x, "new": y})
    return {"status": "pass" if not diffs else "fail", "steps_baseline": len(sb), "steps_new": len(sn),
            "differences": diffs[:8], "n_differences": len(diffs)}


# ----------------------------------------------------------------- comparison
def _num(s):
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def _close(a, b, rel, ab):
    if a == b:
        return True
    if math.isnan(a) and math.isnan(b):
        return True
    return math.isclose(a, b, rel_tol=rel, abs_tol=ab)


class Acc:
    def __init__(self):
        self.cells = self.diffs = 0
        self.max_abs = self.max_rel = 0.0
        self.examples = []

    def add(self, where, a, b, rel, ab, exact=False):
        self.cells += 1
        fa, fb = _num(a), _num(b)
        if fa is not None and fb is not None and not exact:
            ok = _close(fa, fb, rel, ab)
            if not ok:
                d = abs(fa - fb)
                self.max_abs = max(self.max_abs, d)
                self.max_rel = max(self.max_rel, d / abs(fa) if fa else float("inf"))
        else:
            ok = (a == b)
        if not ok:
            self.diffs += 1
            if len(self.examples) < 8:
                self.examples.append({"where": where, "baseline": a, "new": b})

    def result(self, extra=None):
        d = {"status": "pass" if self.diffs == 0 and not extra else "fail",
             "cells_compared": self.cells, "cells_different": self.diffs,
             "max_abs_diff": self.max_abs, "max_rel_diff": self.max_rel, "examples": self.examples}
        if extra:
            d["problem"] = extra
        return d


def compare_table(pa, pb, spec):
    def read(p):
        with open(p, newline="", encoding="utf-8-sig") as fh:
            delim = "\t" if p.lower().endswith(".tsv") else ","
            return list(csv.reader(fh, delimiter=delim))
    A, B = read(pa), read(pb)
    if not A or not B:
        return Acc().result("空文件") if A != B else Acc().result()
    if A[0] != B[0]:
        return Acc().result(f"表头不同：{A[0]} vs {B[0]}")
    if len(A) != len(B):
        return Acc().result(f"行数不同：baseline={len(A)-1} new={len(B)-1}")
    acc = Acc()
    head = A[0]
    for i, (ra, rb) in enumerate(zip(A[1:], B[1:]), start=1):
        if len(ra) != len(rb):
            return acc.result(f"第 {i} 行列数不同")
        for j, (a, b) in enumerate(zip(ra, rb)):
            acc.add(f"row {i}, col '{head[j]}'", a, b, spec["rel_tol"], spec["abs_tol"],
                    exact=head[j] in spec["exact_columns"])
    return acc.result()


def compare_json(pa, pb, spec):
    with open(pa, encoding="utf-8") as fa, open(pb, encoding="utf-8") as fb:
        A, B = json.load(fa), json.load(fb)
    acc = Acc()
    problems = []

    def walk(a, b, path):
        if isinstance(a, dict) and isinstance(b, dict):
            if set(a) != set(b):
                problems.append(f"{path or '/'} 键集合不同")
                return
            for k in sorted(a):
                walk(a[k], b[k], f"{path}/{k}")
        elif isinstance(a, list) and isinstance(b, list):
            if len(a) != len(b):
                problems.append(f"{path or '/'} 长度不同")
                return
            for i, (x, y) in enumerate(zip(a, b)):
                walk(x, y, f"{path}[{i}]")
        elif isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
            acc.add(path or "/", str(a), str(b), spec["rel_tol"], spec["abs_tol"])
        else:
            acc.add(path or "/", json.dumps(a), json.dumps(b), 0, 0)
    walk(A, B, "")
    return acc.result("; ".join(problems) if problems else None)


def compare_file(pa, pb, spec):
    mode = spec["compare"]
    if mode == "none":
        return {"status": "recorded", "note": "仅记录哈希，不比对（如图像文件；请比对其底层数据文件）"}
    if not os.path.exists(pb):
        return {"status": "missing", "note": "运行后没有生成该输出文件"}
    ext = os.path.splitext(pa)[1].lower()
    if mode == "auto":
        mode = "table" if ext in (".csv", ".tsv") else "json" if ext == ".json" else "exact"
    if mode == "table":
        return compare_table(pa, pb, spec)
    if mode == "json":
        return compare_json(pa, pb, spec)
    ha, hb = sha256_file(pa), sha256_file(pb)
    return {"status": "pass" if ha == hb else "fail", "baseline_sha256": ha, "new_sha256": hb}


# ----------------------------------------------------------------- commands
def cmd_scan(root, a):
    rep = scan_mod.scan(root)
    scan_mod.print_report(rep)
    return 1 if rep["summary"]["error"] else 0


def write_report(root, rep):
    with open(os.path.join(root, REPORT_FILE), "w", encoding="utf-8") as fh:
        json.dump(rep, fh, ensure_ascii=False, indent=2, sort_keys=True)
    write_md(root, rep)


def write_md(root, rep):
    L = [f"# 复现审计报告（replication-audit v{VERSION}）", "", f"- 命令：`{rep.get('command')}`",
         f"- 结论：**{rep.get('verdict')}**"]
    if rep.get("mode"):
        L.append(f"- 模式：{rep['mode']}")
    L.append("")
    outs = rep.get("outputs") or rep.get("stability") or []
    if outs:
        L += ["## 输出比对", "", "| 输出文件 | 状态 | 比对单元格 | 不同 | 最大相对差 |", "|---|---|---|---|---|"]
        for r in outs:
            L.append(f"| {r['path']} | {r['status']} | {r.get('cells_compared', '')} | {r.get('cells_different', '')} | "
                     f"{r['max_rel_diff']:.3g} |" if "max_rel_diff" in r else f"| {r['path']} | {r['status']} | | | |")
        for r in outs:
            for ex in r.get("examples", [])[:3]:
                L.append(f"- `{r['path']}` {ex['where']}: {ex['baseline']} → {ex['new']}")
        L.append("")
    if rep.get("flow"):
        L += ["## 样本流（行数变化）", "", "| # | 操作 | 位置 | 输入行数 | 输出行数 |", "|---|---|---|---|---|"]
        for i, e in enumerate(rep["flow"], 1):
            L.append(f"| {i} | {e['op']} | {e['where']} | {', '.join(str(x) for x in e['rows_in'])} | {e['rows_out']} |")
        L.append("")
    if rep.get("flow_flags"):
        L += ["## 样本流提示（需作者解释）", ""] + [f"- {f['id']} 第 {f['step']} 步 `{f['where']}`：{f['message']}" for f in rep["flow_flags"]] + [""]
    if rep.get("flow_check") and rep["flow_check"]["status"] == "fail":
        L += ["## 样本流与基线不一致", ""] + [f"- 第 {d['step']} 步：基线 {d['baseline']} / 本次 {d['new']}" for d in rep["flow_check"]["differences"]] + [""]
    if rep.get("claims"):
        L += ["## 论文数字核对（声明 vs 代码输出）", "", "| 声明 | 论文位置 | 文件[列] | 论文数字 | 输出值 | 结果 |", "|---|---|---|---|---|---|"]
        for c in rep["claims"]:
            L.append(f"| {c['id']} | {c['paper']} | {c['file']}[{c['column']}] | {c['claimed']} | {c['actual']} | {c['status']} |")
        L.append("")
    if rep.get("table_findings"):
        L += ["## 回归表内部一致性提示", ""] + [f"- {f['id']} `{f['file']}` 第 {f['row']} 行：{f['message']}" for f in rep["table_findings"]] + [""]
    if rep.get("orphans"):
        L += ["## 孤立文件（输出目录中存在，但流水线运行后没有重新生成）", ""] + [f"- {o}" for o in rep["orphans"]] + \
             ["", "这类文件可能是手工放入、旧版本残留或粘贴的结果，需作者说明来源。", ""]
    if rep.get("input_problems"):
        L += ["## 输入文件问题", ""] + [f"- {p}" for p in rep["input_problems"]] + [""]
    if rep.get("environment_differences"):
        L += ["## 环境差异", ""] + [f"- {d}" for d in rep["environment_differences"]] + [""]
    L.append("> 本报告由脚本生成；通过审计不代表分析本身正确。发现是线索，不是对不端行为的认定。")
    with open(os.path.join(root, "repro_report.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")


def print_claims(results, table_findings):
    for r in results:
        mark = "OK " if r["status"] == "pass" else "!! "
        extra = "" if r["status"] == "pass" else f"  论文={r['claimed']} 输出={r['actual']}  {r['problem']}"
        print(f"  {mark}声明 {r['id']} ({r['paper']}) {r['file']}[{r['column']}]{extra}")
    for f in table_findings:
        print(f"  ? {f['id']} {f['file']} 第 {f['row']} 行: {f['message']}")


def cleanup(*runs):
    for r in runs:
        if r:
            shutil.rmtree(r["work"], ignore_errors=True)


def print_flags(flags, orphans):
    for f in flags:
        print(f"  ? {f['id']} 第 {f['step']} 步 {f['where']}: {f['message']}")
    if orphans:
        print(f"  ? ORPH 孤立文件 {len(orphans)} 个（输出目录里有，但流水线没有重新生成）：{', '.join(orphans[:6])}")


def cmd_baseline(root, a):
    man = load_manifest(root)
    inputs = hash_inputs(root, man["inputs"])
    originals = artifact_files(root, man["artifact_globs"])
    ra = run_in_copy(root, man, perturbed=False, originals=originals)
    if ra["returncode"] != 0:
        cleanup(ra)
        write_report(root, {"command": "baseline", "verdict": "RUN_FAILED", "log_tail": ra["log_tail"]})
        print(f"基线运行失败（退出码 {ra['returncode']}）：\n{ra['log_tail']}")
        return 1
    rb = run_in_copy(root, man, perturbed=True, originals=originals)
    stability = []
    if rb["returncode"] != 0:
        stability.append({"path": "(run)", "status": "fail",
                          "problem": f"扰动环境下运行失败（退出码 {rb['returncode']}）：{rb['log_tail']}"})
    else:
        for s in man["outputs"]:
            pa = os.path.join(ra["dir"], s["path"])
            r = compare_file(pa, os.path.join(rb["dir"], s["path"]), s) if os.path.exists(pa) \
                else {"status": "missing", "note": "基线运行没有生成该输出文件"}
            stability.append({"path": s["path"], **r})
        if ra["flow"] is not None and rb["flow"] is not None:
            fc = compare_flow(ra["flow"], rb["flow"])
            if fc["status"] == "fail":
                stability.append({"path": "(sample flow)", "status": "fail",
                                  "problem": f"两次运行的样本流不同（{fc['n_differences']} 处）",
                                  "examples": [{"where": f"step {d['step']}", "baseline": d["baseline"], "new": d["new"]}
                                               for d in fc["differences"][:3]]})
    bad = [x for x in stability if x["status"] in ("fail", "missing")]
    flags = flow_flags(ra["flow"])
    if bad and not a.force:
        cleanup(ra, rb)
        write_report(root, {"command": "baseline", "verdict": "UNSTABLE", "outputs": stability})
        print("结论：UNSTABLE —— 同一代码在两个受控环境中给出了不同结果，拒绝保存基线。")
        for x in bad:
            print(f"  - {x['path']}: {x['status']}  {x.get('problem') or x.get('note') or ''}")
            for ex in x.get("examples", [])[:3]:
                print(f"      {ex['where']}: {ex['baseline']} vs {ex['new']}")
        print("常见原因：未设随机种子、依赖集合/字典遍历顺序、线程数、时区、路径。先运行 scan 查看线索。")
        return 2
    bdir = os.path.join(root, BASELINE_DIR)
    shutil.rmtree(bdir, ignore_errors=True)
    outputs = {}
    for s in man["outputs"]:
        src = os.path.join(ra["dir"], s["path"])
        if not os.path.exists(src):
            continue
        dst = os.path.join(bdir, "outputs", s["path"])
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        outputs[s["path"]] = {"sha256": sha256_file(src), "spec": s}
    env = env_snapshot()
    env["tool_info"] = capture_tool_info(root, man)
    base = {"schema": 2, "version": VERSION, "created_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "command": man["command"], "inputs": inputs, "outputs": outputs, "flow": ra["flow"],
            "environment": env, "stability_forced": bool(bad)}
    os.makedirs(bdir, exist_ok=True)
    with open(os.path.join(bdir, "baseline.json"), "w", encoding="utf-8") as fh:
        json.dump(base, fh, ensure_ascii=False, indent=2, sort_keys=True)
    if ra["flow"]:
        with open(os.path.join(bdir, "sample_flow.csv"), "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["step", "op", "where", "rows_in", "rows_out"])
            for i, e in enumerate(ra["flow"], 1):
                w.writerow([i, e["op"], e["where"], "|".join(str(x) for x in e["rows_in"]), e["rows_out"]])
    orphans = ra["orphans"]
    claim_res = claims_mod.evaluate_claims(man["claims"], ra["dir"])
    tfind = claims_mod.table_consistency([s_["path"] for s_ in man["outputs"]], ra["dir"])
    verdict = "BASELINE_SAVED" if not bad else "BASELINE_SAVED_UNSTABLE_FORCED"
    if orphans and man["artifacts_strict"]:
        verdict = "BASELINE_SAVED_WITH_ORPHANS"
    write_report(root, {"command": "baseline", "verdict": verdict, "outputs": stability, "inputs_hashed": len(inputs),
                        "flow": ra["flow"], "flow_flags": flags, "orphans": orphans,
                        "claims": claim_res, "table_findings": tfind})
    cleanup(ra, rb)
    print(f"结论：BASELINE_SAVED —— 两个受控环境结果一致（容差内）。已保存 {len(outputs)} 个输出、{len(inputs)} 个输入的指纹"
          + (f"，记录了 {len(ra['flow'])} 个样本流步骤。" if ra["flow"] is not None else "。"))
    print_flags(flags, orphans)
    print_claims(claim_res, tfind)
    if any(c["status"] != "pass" for c in claim_res):
        print("  ! 注意：有论文声明与代码输出不一致；基线已保存，但 check 将因此失败，直到论文或代码被更正。")
    return 0


def cmd_check(root, a):
    bpath = os.path.join(root, BASELINE_DIR, "baseline.json")
    if not os.path.exists(bpath):
        raise SetupError("没有基线；请先运行 baseline")
    with open(bpath, encoding="utf-8") as fh:
        base = json.load(fh)
    man = load_manifest(root)
    manifest_note = "repro.toml 的运行命令与基线不同" if man["command"] != base["command"] else None
    now_inputs = hash_inputs(root, man["inputs"])
    input_problems = []
    for k, h in base["inputs"].items():
        if k not in now_inputs:
            input_problems.append(f"输入文件缺失：{k}")
        elif now_inputs[k] != h:
            input_problems.append(f"输入文件内容已变化：{k}")
    run = None
    flow = flow_check = None
    orphans = []
    if a.outputs is None:
        run = run_in_copy(root, man, perturbed=False, originals=artifact_files(root, man["artifact_globs"]))
        new_dir = run["dir"]
        if run["returncode"] != 0:
            cleanup(run)
            write_report(root, {"command": "check", "verdict": "FAIL", "reason": "RUN_FAILED",
                                "input_problems": input_problems, "log_tail": run["log_tail"]})
            print(f"结论：FAIL —— 复现运行失败（退出码 {run['returncode']}）：\n{run['log_tail']}")
            return 1
        flow, orphans = run["flow"], run["orphans"]
        if flow is not None and base.get("flow") is not None:
            flow_check = compare_flow(base["flow"], flow)
    else:
        new_dir = os.path.abspath(a.outputs)
    results = []
    for rel, meta in sorted(base["outputs"].items()):
        spec = meta["spec"]  # tolerances come from the baseline snapshot, not the editable manifest
        pa = os.path.join(root, BASELINE_DIR, "outputs", rel)
        results.append({"path": rel, **compare_file(pa, os.path.join(new_dir, rel), spec)})
    claim_res = claims_mod.evaluate_claims(man["claims"], new_dir)
    tfind = claims_mod.table_consistency([m_["spec"]["path"] for m_ in base["outputs"].values()], new_dir)
    cleanup(run)
    failed = [r for r in results if r["status"] in ("fail", "missing")]
    claims_fail = any(c["status"] != "pass" for c in claim_res)
    flow_fail = bool(flow_check and flow_check["status"] == "fail")
    strict_orph = bool(orphans and man["artifacts_strict"])
    verdict = "FAIL" if (failed or input_problems or flow_fail or strict_orph or claims_fail) else "PASS"
    flags = flow_flags(flow)
    env = env_snapshot()
    env["tool_info"] = capture_tool_info(root, man)
    rep = {"command": "check", "verdict": verdict, "mode": "fresh_run" if a.outputs is None else "external_outputs",
           "input_problems": input_problems, "outputs": results, "flow": flow, "flow_flags": flags,
           "flow_check": flow_check, "orphans": orphans, "claims": claim_res, "table_findings": tfind,
           "environment_differences": env_diff(base["environment"], env),
           "notes": [manifest_note] if manifest_note else []}
    write_report(root, rep)
    print(f"结论：{verdict}（模式：{rep['mode']}）")
    for p in input_problems:
        print(f"  ! {p}")
    for r in results:
        line = f"  - {r['path']}: {r['status']}"
        if "cells_compared" in r:
            line += f"  比对单元格 {r['cells_compared']}，不同 {r['cells_different']}，最大相对差 {r['max_rel_diff']:.3g}"
        print(line)
        if r.get("problem"):
            print(f"      {r['problem']}")
        for ex in r.get("examples", [])[:3]:
            print(f"      {ex['where']}: baseline={ex['baseline']} new={ex['new']}")
    if flow_check:
        if flow_check["status"] == "fail":
            print(f"  ! 样本流与基线不一致（{flow_check['n_differences']} 处）：")
            for d in flow_check["differences"][:4]:
                print(f"      第 {d['step']} 步：基线 {d['baseline']} / 本次 {d['new']}")
        else:
            print(f"  - 样本流：{flow_check['steps_new']} 步，与基线一致")
    elif a.outputs is not None:
        print("  · 外部输出模式：未检查样本流与孤立文件")
    print_flags(flags, orphans)
    print_claims(claim_res, tfind)
    if rep["environment_differences"]:
        print("环境差异（可能解释不一致）：")
        for d in rep["environment_differences"][:8]:
            print(f"  · {d}")
    return 0 if verdict == "PASS" else 1


ENTRY_CANDIDATES = ["run_all.py", "main.py", "run.py", "master.py", "replicate.py", "run_all.R", "main.R",
                    "master.R", "run_all.do", "main.do", "master.do"]
OUT_DIRS = ["output", "outputs", "results", "tables", "figures", "figs"]
OUT_EXT = {".csv", ".tsv", ".json", ".png", ".pdf", ".svg", ".tex", ".txt"}
IMG_EXT = {".png", ".pdf", ".svg"}


def cmd_init(root, a):
    path = os.path.join(root, "repro.toml")
    if os.path.exists(path) and not a.force:
        print("repro.toml 已存在；如需覆盖请加 --force")
        return 3
    entry = next((e for e in ENTRY_CANDIDATES if os.path.exists(os.path.join(root, e))), None)
    if not entry:
        pys = sorted(f for f in os.listdir(root) if f.endswith(".py"))
        entry = pys[0] if len(pys) == 1 else None
    low = (entry or "").lower()
    if low.endswith(".py"):
        cmd = f'["python", "{entry}"]'
    elif low.endswith(".r"):
        cmd = f'["Rscript", "{entry}"]'
    elif low.endswith(".do"):
        cmd = f'["stata", "-b", "do", "{entry}"]   # adjust to your executable (e.g. stata-mp, StataMP-64.exe)'
    else:
        cmd = '["python", "run_all.py"]   # TODO: set your single entry command'
    outs = []
    for d in OUT_DIRS:
        for dp, dns, fns in os.walk(os.path.join(root, d)):
            dns[:] = sorted(dns)
            for fn in sorted(fns):
                if os.path.splitext(fn)[1].lower() in OUT_EXT:
                    outs.append(os.path.relpath(os.path.join(dp, fn), root).replace(os.sep, "/"))
    lines = ["# DRAFT generated by `audit.py init` -- review every line before running baseline.", "",
             "[project]", 'name = "' + os.path.basename(root) + '"', f"command = {cmd}", "timeout_seconds = 900", ""]
    if os.path.isdir(os.path.join(root, "data")):
        lines += ["[inputs]", 'files = ["data/**/*"]', ""]
    lines += ["[tolerance]", "rel_tol = 1e-6", "abs_tol = 1e-9", ""]
    if not outs:
        lines += ["# TODO: no existing output files were found; declare the tables/figure data your script writes:",
                  "# [[outputs]]", '# path = "output/table1.csv"', ""]
    for o in outs[:60]:
        lines += ["[[outputs]]", f'path = "{o}"']
        if os.path.splitext(o)[1].lower() in IMG_EXT:
            lines.append('compare = "none"   # image: compare its underlying data file instead')
        lines.append("")
    if len(outs) > 60:
        lines.append(f"# ... {len(outs) - 60} more output files not listed")
    lines += ["[disclosure]", 'ai_used = "undeclared"   # "yes" or "no"', "tools = []", 'scope = ""', ""]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"已生成 repro.toml 草稿：入口={entry or '(未识别)'}，输出文件 {len(outs)} 个。请人工核对后再运行 baseline。")
    return 0


def cmd_provenance(root, a):
    man = load_manifest(root, required=False)
    rep = prov_mod.run(root, (man or {}).get("disclosure", {}))
    if a.with_run:
        if not man:
            raise SetupError("--with-run 需要 repro.toml")
        run = run_in_copy(root, man, perturbed=False, originals=artifact_files(root, man["artifact_globs"]))
        if run["returncode"] == 0:
            for o in run["orphans"]:
                rep["findings"].append({"id": "ORPH001", "severity": "warn", "file": o,
                                        "message": "File sits in an output location but the pipeline did not regenerate it (hand-made, pasted, or stale)."})
            rep["needs_human_review"] = rep["needs_human_review"] or bool(run["orphans"])
        else:
            rep["findings"].append({"id": "ORPH000", "severity": "info", "file": ".",
                                    "message": "Pipeline run failed; orphan check skipped."})
        cleanup(run)
    rep["findings"].sort(key=lambda f: (f["severity"] != "warn", f["file"], f["id"]))
    with open(os.path.join(root, "repro_provenance.json"), "w", encoding="utf-8") as fh:
        json.dump(rep, fh, ensure_ascii=False, indent=2, sort_keys=True)
    print(f"溯源与披露检查（启发式，仅供人工复核）：图像 {len(rep['figures'])} 个；"
          f"warn={sum(1 for f in rep['findings'] if f['severity'] == 'warn')} info={sum(1 for f in rep['findings'] if f['severity'] == 'info')}")
    for f in rep["findings"]:
        print(f"  [{f['severity'].upper():5}] {f['id']} {f['file']}  {f['message']}")
    print("需要人工复核：" + ("是" if rep["needs_human_review"] else "否"))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=f"replication-audit v{VERSION}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("init", "scan", "baseline", "check", "provenance"):
        p = sub.add_parser(name)
        p.add_argument("root", nargs="?", default=".")
        if name in ("baseline", "init"):
            p.add_argument("--force", action="store_true", help="覆盖/即使不稳定也保存基线（不推荐）")
        if name == "check":
            p.add_argument("--outputs", help="已有输出所在的项目根目录（例如另一台机器/另一个 agent 跑出来的），不再重跑")
        if name == "provenance":
            p.add_argument("--with-run", action="store_true", help="另外运行一次流水线以找出孤立文件")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    root = os.path.abspath(a.root)
    try:
        return {"init": cmd_init, "scan": cmd_scan, "baseline": cmd_baseline, "check": cmd_check,
                "provenance": cmd_provenance}[a.cmd](root, a)
    except SetupError as e:
        print(f"设置错误：{e}")
        return 3


if __name__ == "__main__":
    sys.exit(main())
