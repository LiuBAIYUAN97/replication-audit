#!/usr/bin/env python3
"""Run a Python script while logging how the number of rows changes at pandas
merge / join / concat / dropna / drop_duplicates / query / boolean-mask steps.

usage:  trace_wrap.py SCRIPT [args...]        (env REPRO_TRACE_FILE = path of the JSONL log)

Only calls made directly from files inside the current working directory (the
author's code) are logged; calls made inside libraries are ignored.  Each record:
{seq, op, where, rows_in, rows_out, how?}.  Purely observational: results are not changed.
"""
import json
import os
import runpy
import sys

TRACE = os.environ.get("REPRO_TRACE_FILE")
HERE = os.path.abspath(__file__)
CWD = os.path.realpath(os.getcwd())
_seq = [0]


def _emit(rec):
    _seq[0] += 1
    rec["seq"] = _seq[0]
    with open(TRACE, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, sort_keys=True) + "\n")


def _caller():
    """'relpath:line' of the user-code frame that called the wrapper, else None."""
    try:
        f = sys._getframe(2)
        fn = os.path.realpath(f.f_code.co_filename)
    except Exception:
        return None
    if fn == HERE or "site-packages" in fn or not fn.startswith(CWD + os.sep):
        return None
    return f"{os.path.relpath(fn, CWD).replace(os.sep, '/')}:{f.f_lineno}"


def _n(x):
    try:
        return len(x)
    except Exception:
        return None


def install():
    try:
        import pandas as pd
    except Exception:
        _emit({"op": "_unavailable", "where": "", "rows_in": [], "rows_out": None})
        return
    DF = pd.DataFrame

    def wrap_unary(name):
        orig = getattr(DF, name)

        def w(self, *a, **k):
            n_in = len(self)
            out = orig(self, *a, **k)
            where = _caller()
            if where:
                res = out if out is not None else self  # inplace=True
                _emit({"op": name, "where": where, "rows_in": [n_in], "rows_out": _n(res)})
            return out
        w.__name__ = name
        setattr(DF, name, w)

    for nm in ("dropna", "drop_duplicates", "query"):
        wrap_unary(nm)

    def wrap_merge_method(name):
        orig = getattr(DF, name)

        def w(self, other, *a, **k):
            n_l, n_r = len(self), _n(other)
            out = orig(self, other, *a, **k)
            where = _caller()
            if where:
                how = k.get("how") or (a[0] if (name == "merge" and a and isinstance(a[0], str)) else
                                       ("left" if name == "join" else "inner"))
                _emit({"op": name, "where": where, "rows_in": [n_l, n_r], "rows_out": _n(out), "how": str(how)})
            return out
        w.__name__ = name
        setattr(DF, name, w)

    wrap_merge_method("merge")
    wrap_merge_method("join")

    orig_pm = pd.merge

    def pm(left, right, *a, **k):
        n_l, n_r = _n(left), _n(right)
        out = orig_pm(left, right, *a, **k)
        where = _caller()
        if where:
            how = k.get("how") or (a[0] if a and isinstance(a[0], str) else "inner")
            _emit({"op": "merge", "where": where, "rows_in": [n_l, n_r], "rows_out": _n(out), "how": str(how)})
        return out
    pd.merge = pm

    orig_cc = pd.concat

    def cc(objs, *a, **k):
        if not hasattr(objs, "__len__"):  # generator: materialise once so it is not consumed twice
            objs = list(objs)
        vals = list(objs.values()) if isinstance(objs, dict) else list(objs)
        ins = [_n(o) for o in vals]
        out = orig_cc(objs, *a, **k)
        where = _caller()
        if where:
            _emit({"op": "concat", "where": where, "rows_in": ins, "rows_out": _n(out)})
        return out
    pd.concat = cc

    orig_gi = DF.__getitem__

    def gi(self, key):
        out = orig_gi(self, key)
        try:
            if (isinstance(out, DF) and hasattr(key, "dtype") and hasattr(key, "__len__")
                    and pd.api.types.is_bool_dtype(key) and len(out) != len(self)):
                where = _caller()
                if where:
                    _emit({"op": "filter_mask", "where": where, "rows_in": [len(self)], "rows_out": len(out)})
        except Exception:
            pass
        return out
    DF.__getitem__ = gi


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: trace_wrap.py SCRIPT [args...]")
    script = os.path.abspath(sys.argv[1])
    if TRACE:
        open(TRACE, "w").close()
        install()
    sys.argv = [script] + sys.argv[2:]
    sys.path.insert(0, os.path.dirname(script))
    runpy.run_path(script, run_name="__main__")


if __name__ == "__main__":
    main()
