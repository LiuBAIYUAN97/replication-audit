#!/usr/bin/env python3
"""Copy this skill into the skills folder of one or more agents.
  python install.py --target claude|agents|antigravity|all   (or --dest PATH)
Paths differ by agent (the SKILL.md format itself is shared); check your agent's docs if unsure."""
import argparse, os, shutil, sys

TARGETS = {
    "claude": "~/.claude/skills",
    "agents": "~/.agents/skills",            # read by Codex CLI, Cursor, Gemini CLI and others
    "antigravity": "~/.gemini/antigravity/skills",
}
SRC = os.path.dirname(os.path.abspath(__file__))
IGN = shutil.ignore_patterns("__pycache__", "install.py", "*.pyc")

ap = argparse.ArgumentParser()
ap.add_argument("--target", choices=[*TARGETS, "all"])
ap.add_argument("--dest")
a = ap.parse_args()
if not a.target and not a.dest:
    sys.exit("give --target or --dest")
dests = [os.path.expanduser(a.dest)] if a.dest else [os.path.expanduser(p) for k, p in TARGETS.items() if a.target in (k, "all")]
for d in dests:
    out = os.path.join(d, "replication-audit")
    shutil.rmtree(out, ignore_errors=True)
    shutil.copytree(SRC, out, ignore=IGN)
    print("installed ->", out)
