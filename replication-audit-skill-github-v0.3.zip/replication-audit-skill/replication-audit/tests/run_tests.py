#!/usr/bin/env python3
"""End-to-end self-test.  Builds three small demo packages (good / bad / fragile),
runs the audit against them, and checks the expected verdicts.
Requires numpy, pandas, matplotlib in the current Python.   python tests/run_tests.py
"""
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
AUDIT = os.path.join(HERE, "..", "scripts", "audit.py")

RUN_ALL = '''"""Full analysis: raw data -> tables and figure data."""
import os
{imports}
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SEED = 20260101
{seed_line}
{rawpath}
os.makedirs("output", exist_ok=True)
df = pd.read_csv(RAW)
{extra_df}
X = np.column_stack([np.ones(len(df)), df["treat"], df["x"]])
y = df["y"].to_numpy()
n, k = X.shape
beta, *_ = np.linalg.lstsq(X, y, rcond=None)
resid = y - X @ beta
se = np.sqrt(np.diag(resid @ resid / (n - k) * np.linalg.inv(X.T @ X)))
{hardcode}
{rng_line}
boot = np.empty(300)
for b in range(300):
    idx = rng.integers(0, n, n)
    bb, *_ = np.linalg.lstsq(X[idx], y[idx], rcond=None)
    boot[b] = bb[1]
terms = {terms}
table = pd.DataFrame({{"term": terms, "coef": [dict(zip(["const", "treat", "x"], beta))[t] for t in terms],
                      "se": [dict(zip(["const", "treat", "x"], se))[t] for t in terms],
                      "n": [n] * 3}})
{table_extra}
table.to_csv("output/table1_main.csv", index=False)
pd.DataFrame({{"stat": ["boot_se_treat"], "value": [boot.std(ddof=1)]}}).to_csv("output/table2_boot.csv", index=False)
fig, ax = plt.subplots()
ax.hist(boot, bins=20)
fig.savefig("output/fig1.png")
{show}
'''

MANIFEST = '''[project]
name = "demo"
command = ["python", "run_all.py"]
timeout_seconds = 300

[inputs]
files = ["data/raw/*.csv"]

[tolerance]
rel_tol = 1e-6
abs_tol = 1e-9

[[outputs]]
path = "output/table1_main.csv"
exact_columns = ["n"]

[[outputs]]
path = "output/table2_boot.csv"

[[outputs]]
path = "output/fig1.png"
compare = "none"
'''


def make_pkg(dest, kind):
    import numpy as np
    os.makedirs(os.path.join(dest, "data", "raw"), exist_ok=True)
    rng = np.random.default_rng(7)
    with open(os.path.join(dest, "data", "raw", "panel.csv"), "w") as fh:
        fh.write("id,treat,x,y\n")
        for i in range(400):
            t, x = int(rng.integers(0, 2)), rng.normal()
            fh.write(f"{i},{t},{x:.6f},{1 + 0.5 * t + 0.3 * x + rng.normal():.6f}\n")
    p = dict(imports="", seed_line="np.random.seed(SEED)", rawpath='RAW = "data/raw/panel.csv"',
             extra_df="", hardcode="", rng_line="rng = np.random.default_rng(SEED)",
             terms='["const", "treat", "x"]', show="", table_extra="")
    if kind == "bad":
        p.update(
            seed_line="",
            rawpath='RAW = "/Users/zhang/project/data/raw/panel.csv"\nif not os.path.exists(RAW):\n    RAW = "data/raw/panel.csv"',
            extra_df='df = df.merge(df[["id"]].assign(flag=1), on="id")\ntry:\n    df = df.dropna()\nexcept Exception:\n    pass',
            hardcode="beta_treat = 0.4123",
            rng_line="rng = np.random.default_rng()",
            show="plt.show()")
    if kind == "flow":
        p.update(extra_df='dup = pd.DataFrame({"id": [1, 1, 2], "w": [1, 2, 3]})\n'
                          'df = df.merge(dup, on="id", how="left")\n'
                          'df = df[df["x"] > -0.5]')
    if kind == "tbl_ok":
        p.update(imports="import math",
                 table_extra='table["t"] = table["coef"] / table["se"]\n'
                             'table["p"] = [math.erfc(abs(v) / math.sqrt(2)) for v in table["t"]]')
    if kind == "tbl_bad":
        p.update(table_extra='table["t"] = 1.0\ntable["p"] = 0.0001')
    if kind == "fragile":
        p.update(terms='list({"const", "treat", "x"})')  # set order depends on PYTHONHASHSEED
    with open(os.path.join(dest, "run_all.py"), "w") as fh:
        fh.write(RUN_ALL.format(**p))
    with open(os.path.join(dest, "repro.toml"), "w") as fh:
        fh.write(MANIFEST)
    with open(os.path.join(dest, "README.md"), "w") as fh:
        fh.write("# demo package\nRun: python run_all.py\n")
    if kind != "bad":
        import numpy, pandas, matplotlib
        with open(os.path.join(dest, "requirements.txt"), "w") as fh:
            fh.write(f"numpy=={numpy.__version__}\npandas=={pandas.__version__}\nmatplotlib=={matplotlib.__version__}\n")


def audit(*args):
    r = subprocess.run([sys.executable, AUDIT, *args], capture_output=True, text=True, encoding="utf-8")
    return r.returncode, r.stdout + r.stderr


results = []


def expect(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}")
    if not cond:
        print("      " + detail.replace("\n", "\n      ")[:1200])


def main():
    tmp = tempfile.mkdtemp(prefix="ra_test_")
    try:
        good, bad, frag = (os.path.join(tmp, k) for k in ("good", "bad", "fragile"))
        for d, k in ((good, "good"), (bad, "bad"), (frag, "fragile")):
            make_pkg(d, k)

        rc, out = audit("scan", good)
        expect("T1 scan: clean package has no errors", rc == 0 and "error=0" in out, out)

        rc, out = audit("scan", bad)
        need = ["R001", "R005", "R009", "R011", "R013", "R014", "P002"]
        expect("T2 scan: bad package flags seed/path/merge/hardcode/show/except/lock",
               rc == 1 and all(i in out for i in need), out)

        rc, out = audit("baseline", good)
        expect("T3 baseline: good package is stable and saved", rc == 0 and "BASELINE_SAVED" in out, out)

        rc, out = audit("check", good)
        expect("T4 check: fresh run reproduces baseline", rc == 0 and "PASS" in out, out)

        # T5: analysis changed (sample silently restricted) -> must fail and name the cell
        tam = os.path.join(tmp, "tampered")
        shutil.copytree(good, tam)
        src = open(os.path.join(tam, "run_all.py")).read().replace(
            "df = pd.read_csv(RAW)", "df = pd.read_csv(RAW)\ndf = df[df['x'] > -1.0]")
        open(os.path.join(tam, "run_all.py"), "w").write(src)
        rc, out = audit("check", tam)
        expect("T5 check: silent sample restriction is caught (n and coef differ)",
               rc == 1 and "FAIL" in out and "col 'n'" in out, out)

        # T6: loosening tolerance in repro.toml must not rescue a failing check
        mt = open(os.path.join(tam, "repro.toml")).read().replace("rel_tol = 1e-6", "rel_tol = 0.9")
        open(os.path.join(tam, "repro.toml"), "w").write(mt)
        rc, out = audit("check", tam)
        expect("T6 check: editing tolerances in repro.toml does not hide the failure", rc == 1, out)

        # T7: outputs produced elsewhere (other machine / other agent) are compared, not re-run
        other = os.path.join(tmp, "other_machine")
        shutil.copytree(good, other, ignore=shutil.ignore_patterns("repro_baseline", "repro_report.json"))
        env = dict(os.environ, PYTHONHASHSEED="999", OMP_NUM_THREADS="3")
        subprocess.run([sys.executable, "run_all.py"], cwd=other, env=env, check=True, capture_output=True)
        rc, out = audit("check", good, "--outputs", other)
        expect("T7 check --outputs: externally produced results match baseline", rc == 0 and "external_outputs" in out, out)

        # T8: changed input data is detected
        dat = os.path.join(tmp, "data_changed")
        shutil.copytree(good, dat)
        with open(os.path.join(dat, "data", "raw", "panel.csv"), "a") as fh:
            fh.write("9999,1,0.1,1.0\n")
        rc, out = audit("check", dat)
        expect("T8 check: modified raw data is flagged", rc == 1 and "输入文件内容已变化" in out, out)

        rc, out = audit("baseline", bad)
        expect("T9 baseline: unseeded randomness is refused as UNSTABLE", rc == 2 and "UNSTABLE" in out, out)

        rc, out = audit("baseline", frag)
        expect("T10 baseline: hash-order dependence is exposed by the perturbed run", rc == 2 and "UNSTABLE" in out, out)

        # ---------------- v0.2 ----------------
        def write(path, text):
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(text)

        # T11 Stata / R static rules
        st = os.path.join(tmp, "stata_bad")
        write(os.path.join(st, "analysis.do"),
              "* demo\ncd \"C:\\Users\\zhang\\project\"\nuse data.dta, clear\ngen u = runiform()\n"
              "merge m:m id using other\nsort id\nssc install estout\ncapture reg y x\ngen beta_main = 0.4123\n")
        rc, out = audit("scan", st)
        expect("T11a scan Stata: seed/version/path/m:m/sort/install/capture/hardcode flagged",
               all(i in out for i in ["ST001", "ST002", "ST003", "ST004", "ST005", "ST006", "ST007", "ST009"]), out)
        stok = os.path.join(tmp, "stata_ok")
        write(os.path.join(stok, "analysis.do"), "version 17\nset seed 12345\ngen u = runiform()\nsort id, stable\n")
        rc, out = audit("scan", stok)
        expect("T11b scan Stata: seed + version present -> no ST001/ST002", "ST001" not in out and "ST002" not in out, out)
        rr = os.path.join(tmp, "r_bad")
        write(os.path.join(rr, "analysis.R"),
              'setwd("/Users/zhang/proj")\nx <- rnorm(100)\ninstall.packages("fixest")\n'
              'res <- try(lm(y~x), silent=TRUE)\nname <- readline("go?")\nbeta_hat <- 0.7123\n'
              'library(parallel)\nmclapply(1:3, function(i) rnorm(1))\n')
        rc, out = audit("scan", rr)
        expect("T11c scan R: seed/path/renv/install/try/readline/parallel/hardcode flagged",
               all(i in out for i in ["RR001", "RR002", "RR003", "RR004", "RR005", "RR006", "RR007", "RR008"]), out)

        # T12 sample-flow tracing
        flow = os.path.join(tmp, "flow")
        make_pkg(flow, "flow")
        rc, out = audit("baseline", flow)
        expect("T12a baseline traces sample flow and flags merge fan-out and big drop",
               rc == 0 and "TR001" in out and "TR002" in out and
               os.path.exists(os.path.join(flow, "repro_baseline", "sample_flow.csv")), out)
        rc, out = audit("check", flow)
        expect("T12b check: sample flow identical to baseline", rc == 0 and "样本流" in out and "一致" in out, out)
        md = open(os.path.join(flow, "repro_report.md"), encoding="utf-8").read()
        expect("T12c markdown report contains sample-flow table", "样本流（行数变化）" in md and "filter_mask" in md, md[:600])
        ft = os.path.join(tmp, "flow_tampered")
        shutil.copytree(flow, ft)
        src = open(os.path.join(ft, "run_all.py"), encoding="utf-8").read().replace("> -0.5", "> -0.4")
        open(os.path.join(ft, "run_all.py"), "w", encoding="utf-8").write(src)
        rc, out = audit("check", ft)
        expect("T12d check: changed filter shows up as sample-flow difference", rc == 1 and "样本流与基线不一致" in out, out)

        # T13 orphan artifacts (hand-placed file in the output folder)
        orp = os.path.join(tmp, "orphan")
        shutil.copytree(good, orp)
        write(os.path.join(orp, "output", "fig_manual.png"), "not produced by the pipeline")
        rc, out = audit("check", orp)
        expect("T13a check: orphan file reported, verdict still PASS by default", rc == 0 and "ORPH" in out and "fig_manual.png" in out, out)
        with open(os.path.join(orp, "repro.toml"), "a", encoding="utf-8") as fh:
            fh.write("\n[artifacts]\nstrict = true\n")
        rc, out = audit("check", orp)
        expect("T13b check: strict artifacts makes an orphan a FAIL", rc == 1 and "FAIL" in out, out)

        # T14 figure metadata + disclosure heuristics
        pv = os.path.join(tmp, "prov")
        shutil.copytree(good, pv, ignore=shutil.ignore_patterns("repro_baseline", "repro_report.*"))
        subprocess.run([sys.executable, "run_all.py"], cwd=pv, check=True, capture_output=True)

        def chunk(t, d):
            return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
        fake = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0)) +
                chunk(b"tEXt", b"Software\x00Midjourney v6") +
                chunk(b"IDAT", zlib.compress(b"\x00\xff\x00\x00")) + chunk(b"IEND", b""))
        open(os.path.join(pv, "output", "fig_fake.png"), "wb").write(fake)
        with open(os.path.join(pv, "repro.toml"), "a", encoding="utf-8") as fh:
            fh.write('\n[disclosure]\nai_used = "no"\n')
        with open(os.path.join(pv, "run_all.py"), "a", encoding="utf-8") as fh:
            fh.write('\n# draft written with ChatGPT help\nTMP = "path/to/data.csv"\n')
        rc, out = audit("provenance", pv)
        rep = json.load(open(os.path.join(pv, "repro_provenance.json"), encoding="utf-8"))
        by = {f["file"]: f for f in rep["figures"]}
        expect("T14a provenance: AI marker in PNG metadata flagged (FIG001)", "FIG001" in out and "output/fig_fake.png" in out, out)
        expect("T14b provenance: matplotlib figure recognised as plotting-software output",
               by["output/fig1.png"]["producer_known"] is True and by["output/fig_fake.png"]["producer_known"] is False,
               json.dumps(by, indent=1)[:800])
        expect("T14c provenance: declared 'no AI' vs ChatGPT mention -> DISC001; placeholder -> DISC005",
               "DISC001" in out and "DISC005" in out and rep["needs_human_review"] is True, out)
        if shutil.which("git"):
            g = ["git", "-c", "user.name=t", "-c", "user.email=t@t"]
            subprocess.run(["git", "init", "-q"], cwd=pv, check=True, capture_output=True)
            subprocess.run(["git", "add", "-A"], cwd=pv, check=True, capture_output=True)
            subprocess.run(g + ["commit", "-q", "-m", "add analysis\n\nCo-Authored-By: Claude <noreply@anthropic.com>"],
                           cwd=pv, check=True, capture_output=True)
            rc, out = audit("provenance", pv)
            rep = json.load(open(os.path.join(pv, "repro_provenance.json"), encoding="utf-8"))
            expect("T14d provenance: AI co-author trailer in git history is detected", len(rep["disclosure"]["git_signals"]) == 1, out)

        # T15 init -> baseline round trip
        ini = os.path.join(tmp, "init_pkg")
        shutil.copytree(good, ini, ignore=shutil.ignore_patterns("repro_baseline", "repro_report.*"))
        subprocess.run([sys.executable, "run_all.py"], cwd=ini, check=True, capture_output=True)
        os.remove(os.path.join(ini, "repro.toml"))
        rc, out = audit("init", ini)
        toml_txt = open(os.path.join(ini, "repro.toml"), encoding="utf-8").read()
        expect("T15a init drafts entry command and discovers outputs",
               rc == 0 and '"run_all.py"' in toml_txt and "output/table1_main.csv" in toml_txt and 'compare = "none"' in toml_txt, toml_txt)
        rc, out = audit("baseline", ini)
        expect("T15b baseline works on the drafted manifest, no orphans", rc == 0 and "ORPH" not in out, out)

        # T16 non-Python tool info is captured and diffed
        envp = os.path.join(tmp, "envcap")
        shutil.copytree(good, envp, ignore=shutil.ignore_patterns("repro_baseline", "repro_report.*"))
        with open(os.path.join(envp, "repro.toml"), "a", encoding="utf-8") as fh:
            fh.write('\n[env_capture]\ncommand = ["python", "-c", "print(\'stata-like 17.0\')"]\n')
        rc, out = audit("baseline", envp)
        saved = open(os.path.join(envp, "repro_baseline", "baseline.json"), encoding="utf-8").read()
        expect("T16 env_capture output stored in baseline", rc == 0 and "stata-like 17.0" in saved, out)

        # ---------------- v0.3 ----------------
        # T17 regression-table internal consistency
        tok, tbad = os.path.join(tmp, "tbl_ok"), os.path.join(tmp, "tbl_bad")
        make_pkg(tok, "tbl_ok")
        make_pkg(tbad, "tbl_bad")
        rc, out = audit("baseline", tok)
        expect("T17a consistent t/p columns raise no TB findings", rc == 0 and "TB001" not in out and "TB002" not in out, out)
        rc, out = audit("baseline", tbad)
        expect("T17b t that is not coef/se, and p=0.0001 reported for t=1, are flagged", rc == 0 and "TB001" in out and "TB002" in out, out)

        # T18 paper claims vs outputs
        cl = os.path.join(tmp, "claims")
        shutil.copytree(good, cl, ignore=shutil.ignore_patterns("repro_baseline", "repro_report.*"))
        subprocess.run([sys.executable, "run_all.py"], cwd=cl, check=True, capture_output=True)
        import csv as _csv
        rows = list(_csv.DictReader(open(os.path.join(cl, "output", "table1_main.csv"), encoding="utf-8")))
        coef = float(next(r for r in rows if r["term"] == "treat")["coef"])
        shutil.rmtree(os.path.join(cl, "output"))

        def claim_block(value_str):
            return ('\n[[claims]]\nid = "main_effect"\npaper = "Table 2, col 1"\n'
                    'file = "output/table1_main.csv"\ncolumn = "coef"\nselect = { term = "treat" }\n'
                    f'value = "{value_str}"\n'
                    '\n[[claims]]\nid = "sample_size"\npaper = "Table 2 N"\nfile = "output/table1_main.csv"\n'
                    'column = "n"\nselect = { term = "const" }\nvalue = 400\n')
        with open(os.path.join(cl, "repro.toml"), "a", encoding="utf-8") as fh:
            fh.write(claim_block(f"{coef:.3f}"))
        rc, out = audit("baseline", cl)
        expect("T18a baseline: correct paper claims verified", rc == 0 and "声明 main_effect" in out and "!!" not in out, out)
        rc, out = audit("check", cl)
        expect("T18b check: PASS when paper numbers match outputs", rc == 0 and "PASS" in out, out)
        with open(os.path.join(cl, "repro.toml"), "w", encoding="utf-8") as fh:
            fh.write(MANIFEST + claim_block(f"{coef + 0.05:.3f}"))
        rc, out = audit("check", cl)
        expect("T18c check: a paper number that no longer matches the output makes check FAIL",
               rc == 1 and "论文数字与代码输出不一致" in out, out)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    ok = sum(1 for _, c in results if c)
    print(f"\n{ok}/{len(results)} tests passed")
    return 0 if ok == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
