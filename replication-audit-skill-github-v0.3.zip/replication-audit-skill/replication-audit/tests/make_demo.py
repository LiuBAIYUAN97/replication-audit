#!/usr/bin/env python3
"""Create demo packages to try the tool by hand.
   python tests/make_demo.py DEST      ->  DEST/good, DEST/bad, DEST/flow
Requires numpy, pandas, matplotlib."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_tests  # noqa: E402

if len(sys.argv) != 2:
    sys.exit(__doc__)
dest = os.path.abspath(sys.argv[1])
for kind in ("good", "bad", "flow"):
    run_tests.make_pkg(os.path.join(dest, kind), kind)
    print("created", os.path.join(dest, kind))
