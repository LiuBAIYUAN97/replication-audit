# Changelog

## 0.3
- 论文数字核对：`repro.toml` 中的 `[[claims]]`；回归表自洽检查（TB001/TB002）
- 新增 `tests/make_demo.py`、中文快速上手

## 0.2
- Stata / R 静态扫描规则
- pandas 样本流追踪（TR001–TR003），`check` 要求样本流与基线一致
- 孤立文件检查；图像元数据与 AI 披露核对（`provenance` 命令，启发式）
- `init` 命令；Markdown 报告；`[env_capture]`、`[artifacts]`、`[disclosure]` 配置

## 0.1
- Python 静态扫描；双环境基线；容差比对；基线锁定容差
